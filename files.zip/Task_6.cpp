/*
============================================================
  Task 6 - Recursive BinarySearchTree Functions
  Lab 09 - Spring 2026 - Data Structures D20
============================================================

--- STEP 1: What I understand about the task ---
Is task mein mujhe BinarySearchTree (BST) par recursive functions likhne hain.
BST mein har node ke left child ki value choti hoti hai aur right child ki badi.
Mujhe yeh karna hai:
1. Tree ki height nikaalni hai
2. Total nodes count karne hain
3. Leaf nodes count karne hain (jinke koi children nahi)
4. Tree ki deep copy banana hai
5. Inorder traversal se display karna hai (left, root, right)
6. Preorder traversal se search karna hai (root, left, right)
7. BST property use karke efficient search karna hai

--- STEP 2: How I will solve it ---
1. height(root):
   Base case: root == null -> return -1 (empty tree height = -1, single node = 0)
   Recursion: 1 + max(height(left), height(right))
   Tree: A(B,C) -> height = 1 + max(height(B), height(C)) = 1 + max(0,0) = 1

2. countNodes(root):
   Base case: root == null -> return 0
   Recursion: 1 + countNodes(left) + countNodes(right)

3. countLeaves(root):
   Base case: root == null -> return 0
   Leaf node (no children): return 1
   Recursion: countLeaves(left) + countLeaves(right)

4. copyTree(root):
   Base case: root == null -> return null
   Create new node with same data
   new->left = copyTree(root->left)
   new->right = copyTree(root->right)

5. inorderDisplay(root):
   Base case: root == null -> return
   inorderDisplay(left), print root, inorderDisplay(right)
   Result: sorted order (BST property)

6. preorderSearch(root, value):
   Base case: root == null -> return false
   Check root first, then left, then right
   If root matches -> return true

7. BST Search: Use BST property - go left if value < root, right if value > root

--- STEP 3: Functions I will reuse ---
- height() ki max() helper reuse karunga countNodes waale pattern mein.
- copyTree() mein preorder pattern (root first, then children) reuse hota hai.
- preorderSearch aur BST search mein base case pattern same hai.

Tree progression (inorder: left->root->right):
      5
     / \
    3   7
   / \ / \
  2  4 6  8
Inorder: 2->3->4->5->6->7->8 (sorted!)
Preorder: 5->3->2->4->7->6->8

--- STEP 4: What I learned ---
Maine seekha ke recursion BST operations ke liye bahut natural hai
kyunki har node apne aap ek subtree ka root hai.
Height mein empty tree ka -1 return karna important hai taake single node = 0 ho.
Deep copy mein har node naya banana padta hai - sirf pointer copy karna shallow copy hoti hai.

--- STEP 5: Skills developed ---
Ab main BST par saare basic recursive operations kar sakta hun.
Main preorder, inorder traversal implement kar sakta hun.
Main tree copy (deep), search, aur structural analysis (height, count) kar sakta hun.
============================================================
*/

#include <iostream>
using namespace std;

// ===== Node class as given in lab =====
template <class T>
class Node {
public:
    T data;
    Node* left;
    Node* right;

    Node(T val) : data(val), left(nullptr), right(nullptr) {}
};

// ===== BST Insert helper (for building test trees) =====
template <class T>
Node<T>* bstInsert(Node<T>* root, T value) {
    if (root == nullptr) return new Node<T>(value);
    if (value < root->data) root->left = bstInsert(root->left, value);
    else if (value > root->data) root->right = bstInsert(root->right, value);
    return root;
}

// ===== Helper: max of two ints =====
int myMax(int a, int b) { return (a > b) ? a : b; }

// 1. Height of tree
template <class T>
int height(Node<T>* treeRoot) {
    if (treeRoot == nullptr) return -1; // empty tree height = -1
    int leftH = height(treeRoot->left);
    int rightH = height(treeRoot->right);
    return 1 + myMax(leftH, rightH);
}

// 2. Count all nodes
template <class T>
int countNodes(Node<T>* treeRoot) {
    if (treeRoot == nullptr) return 0;
    return 1 + countNodes(treeRoot->left) + countNodes(treeRoot->right);
}

// 3. Count leaf nodes (nodes with no children)
template <class T>
int countLeaves(Node<T>* treeRoot) {
    if (treeRoot == nullptr) return 0;
    if (treeRoot->left == nullptr && treeRoot->right == nullptr)
        return 1; // This is a leaf
    return countLeaves(treeRoot->left) + countLeaves(treeRoot->right);
}

// 4. Deep copy of tree
template <class T>
Node<T>* copyTree(Node<T>* treeRoot) {
    if (treeRoot == nullptr) return nullptr;
    Node<T>* newNode = new Node<T>(treeRoot->data);
    newNode->left = copyTree(treeRoot->left);
    newNode->right = copyTree(treeRoot->right);
    return newNode;
}

// 5. Inorder Display: Left -> Root -> Right (gives sorted output for BST)
template <class T>
void inorderDisplay(Node<T>* root) {
    if (root == nullptr) return;
    inorderDisplay(root->left);
    cout << root->data << " ";
    inorderDisplay(root->right);
}

// 6. Preorder Search: Root -> Left -> Right (searches all nodes in preorder)
template <class T>
bool preorderSearch(Node<T>* root, T value) {
    if (root == nullptr) return false;
    if (root->data == value) return true;          // Found at root
    if (preorderSearch(root->left, value)) return true;  // Search left
    return preorderSearch(root->right, value);     // Search right
}

// 7. BST Search: Uses BST property (left < root < right) for efficient O(log n) search
template <class T>
bool bstSearch(Node<T>* root, T value) {
    if (root == nullptr) return false;
    if (root->data == value) return true;
    if (value < root->data) return bstSearch(root->left, value);  // Go left
    return bstSearch(root->right, value);                          // Go right
}

// Helper to free tree memory
template <class T>
void freeTree(Node<T>* root) {
    if (root == nullptr) return;
    freeTree(root->left);
    freeTree(root->right);
    delete root;
}

// ===== MAIN =====
int main() {
    cout << "===== Task 6: Recursive BST Functions =====" << endl;

    // Build a BST:
    //        5
    //       / \
    //      3   7
    //     / \ / \
    //    2  4 6  8
    //   /
    //  1

    Node<int>* tree = nullptr;
    tree = bstInsert(tree, 5);
    tree = bstInsert(tree, 3);
    tree = bstInsert(tree, 7);
    tree = bstInsert(tree, 2);
    tree = bstInsert(tree, 4);
    tree = bstInsert(tree, 6);
    tree = bstInsert(tree, 8);
    tree = bstInsert(tree, 1);

    // 1. Height
    cout << "\n--- height ---" << endl;
    cout << "Height: " << height(tree) << endl;  // Expected: 3 (root->3->2->1)

    // 2. Count Nodes
    cout << "\n--- countNodes ---" << endl;
    cout << "Total nodes: " << countNodes(tree) << endl;  // Expected: 8

    // 3. Count Leaves
    cout << "\n--- countLeaves ---" << endl;
    cout << "Leaf nodes: " << countLeaves(tree) << endl;  // Expected: 4 (1,4,6,8)

    // 4. Copy Tree
    cout << "\n--- copyTree ---" << endl;
    Node<int>* treeCopy = copyTree(tree);
    cout << "Original inorder: ";
    inorderDisplay(tree);
    cout << endl;
    cout << "Copied   inorder: ";
    inorderDisplay(treeCopy);
    cout << endl;
    cout << "Same addresses? " << (tree == treeCopy ? "YES (shallow!)" : "NO (deep copy - correct!)") << endl;

    // 5. Inorder Display
    cout << "\n--- inorderDisplay ---" << endl;
    cout << "Inorder (should be sorted): ";
    inorderDisplay(tree);   // Expected: 1 2 3 4 5 6 7 8
    cout << endl;

    // 6. Preorder Search
    cout << "\n--- preorderSearch ---" << endl;
    cout << "Search 4: " << (preorderSearch(tree, 4) ? "Found" : "Not Found") << endl;  // Found
    cout << "Search 9: " << (preorderSearch(tree, 9) ? "Found" : "Not Found") << endl;  // Not Found
    cout << "Search 1: " << (preorderSearch(tree, 1) ? "Found" : "Not Found") << endl;  // Found

    // 7. BST Search (efficient)
    cout << "\n--- bstSearch (BST property) ---" << endl;
    cout << "BST Search 6: " << (bstSearch(tree, 6) ? "Found" : "Not Found") << endl;  // Found
    cout << "BST Search 0: " << (bstSearch(tree, 0) ? "Found" : "Not Found") << endl;  // Not Found
    cout << "BST Search 5: " << (bstSearch(tree, 5) ? "Found" : "Not Found") << endl;  // Found (root)

    // Free memory
    freeTree(tree);
    freeTree(treeCopy);

    return 0;
}
