/*
============================================================
  Task 1 - Recursive String Functions
  Lab 09 - Spring 2026 - Data Structures D20
============================================================

--- STEP 1: What I understand about the task ---
Is task mein mujhe char arrays (C-style strings) par kaam karne wale recursive functions likhne hain.
Koi loop use nahi kar sakta - sirf recursion se saare kaam karne hain:
- Sentence mein words count karna
- Sentence mein characters count karna
- Sentence ko character-wise ulta karna
- Sentence ko word-wise ulta karna
- Lowercase ko uppercase aur uppercase ko lowercase mein convert karna

--- STEP 2: How I will solve it ---
1. countWords: Har call mein ek character dekhta hun. Agar space mile aur uske baad koi character ho,
   toh ek word count karta hun. Base case: jab string khatam ho (\0).

2. countCharacters: Har recursive call mein ek character count karta hun jab tak \0 na mile.

3. reverse: Do pointers use karta hun - ek shuruaat se, ek end se. Swap karke andar aata hun.
   Progression: "hello" -> swap h,o -> "oellh" -> swap e,l -> "olleh"

4. reverseWords: Pehle puri string reverse karunga (character-wise), phir har word ko dobara reverse karunga.
   Example: "hello world" -> char reverse -> "dlrow olleh" -> word reverse -> "world hello"

5. convert: Har character check karta hun - agar lowercase hai toh uppercase banata hun aur vice versa.

--- STEP 3: Functions I will reuse ---
- reverse() function reverseWords() mein reuse karunga kyunki word reversal ke liye
  pehle puri string reverse karni hoti hai, phir each word ko alag se.
- strlen() sirf length pata karne ke liye use karunga.
Progression (reverse example): A -> B -> C -> \0 (base) -> C -> B -> A

--- STEP 4: What I learned ---
Maine seekha ke recursion mein hamesha ek base case honi chahiye jo loop ko rok sake.
String recursion mein base case usually \0 (null terminator) hoti hai.
Mujhe pata chala ke kuch problems (jaise reverse) mein do pointers ki zarurat hoti hai.

--- STEP 5: Skills developed ---
Ab main C-style strings par recursive operations kar sakta hun.
Main samajhta hun ke kaise do-pointer technique se in-place reversal hoti hai.
Main aisi problems solve kar sakta hun jahan sequence mein elements process karne hain.
============================================================
*/

#include <iostream>
#include <cstring>
using namespace std;

// Helper: string length (recursive)
int myStrLen(const char* s) {
    if (*s == '\0') return 0;
    return 1 + myStrLen(s + 1);
}

// 1. Count words in a sentence (recursive)
void countWordsHelper(const char* sentence, int& count, bool inWord) {
    if (*sentence == '\0') {
        // If we were inside a word when string ended, count it
        if (inWord) count++;
        return;
    }
    if (*sentence == ' ') {
        if (inWord) count++; // word just ended
        countWordsHelper(sentence + 1, count, false);
    } else {
        countWordsHelper(sentence + 1, count, true);
    }
}

void countWords(const char* sentence) {
    int count = 0;
    countWordsHelper(sentence, count, false);
    cout << "Word count: " << count << endl;
}

// 2. Count characters (recursive, excluding null terminator)
void countCharactersHelper(const char* sentence, int& count) {
    if (*sentence == '\0') return;
    count++;
    countCharactersHelper(sentence + 1, count);
}

void countCharaters(const char* sentence) {
    int count = 0;
    countCharactersHelper(sentence, count);
    cout << "Character count: " << count << endl;
}

// 3. Reverse string character-wise (in-place, recursive)
void reverseHelper(char* left, char* right) {
    if (left >= right) return; // base case: pointers met or crossed
    // Swap
    char temp = *left;
    *left = *right;
    *right = temp;
    reverseHelper(left + 1, right - 1);
}

void reverse(char*& sentence) {
    int len = myStrLen(sentence);
    if (len <= 1) return;
    reverseHelper(sentence, sentence + len - 1);
}

// 4. Reverse words in sentence (recursive helper to reverse each word)
void reverseWordHelper(char* start, char* end) {
    if (start >= end) return;
    char temp = *start;
    *start = *end;
    *end = temp;
    reverseWordHelper(start + 1, end - 1);
}

void reverseEachWord(char* sentence) {
    if (*sentence == '\0') return;
    // Find start of word (skip spaces)
    while (*sentence == ' ' && *sentence != '\0') sentence++;
    if (*sentence == '\0') return;
    // Find end of word
    char* wordStart = sentence;
    while (*sentence != ' ' && *sentence != '\0') sentence++;
    char* wordEnd = sentence - 1;
    // Reverse this word
    reverseWordHelper(wordStart, wordEnd);
    // Recurse for rest
    reverseEachWord(sentence);
}

void reverseWords(char*& sentence) {
    // Step 1: Reverse entire string
    reverse(sentence);
    // Step 2: Reverse each word back
    reverseEachWord(sentence);
}

// 5. Convert case (lower->upper, upper->lower) recursive
void convert(char* sentence) {
    if (*sentence == '\0') return;
    if (*sentence >= 'a' && *sentence <= 'z')
        *sentence = *sentence - 32; // lowercase to uppercase
    else if (*sentence >= 'A' && *sentence <= 'Z')
        *sentence = *sentence + 32; // uppercase to lowercase
    convert(sentence + 1);
}

// ==================== MAIN ====================
int main() {
    cout << "===== Task 1: Recursive String Functions =====" << endl;

    // Test countWords
    cout << "\n--- countWords ---" << endl;
    countWords("Hello World how are you");   // 5
    countWords("  spaces  between  ");       // 2
    countWords("single");                    // 1

    // Test countCharacters
    cout << "\n--- countCharacters ---" << endl;
    countCharaters("Hello World");           // 11
    countCharaters("abc");                   // 3

    // Test reverse (character-wise)
    cout << "\n--- reverse (char-wise) ---" << endl;
    char s1[] = "Hello World";
    char* p1 = s1;
    cout << "Before: " << p1 << endl;
    reverse(p1);
    cout << "After:  " << p1 << endl;  // dlroW olleH

    // Test reverseWords
    cout << "\n--- reverseWords ---" << endl;
    char s2[] = "Hello World Test";
    char* p2 = s2;
    cout << "Before: " << p2 << endl;
    reverseWords(p2);
    cout << "After:  " << p2 << endl;  // Test World Hello

    // Test convert
    cout << "\n--- convert (case flip) ---" << endl;
    char s3[] = "Hello World 123";
    cout << "Before: " << s3 << endl;
    convert(s3);
    cout << "After:  " << s3 << endl;  // hELLO wORLD 123

    return 0;
}
