/*
============================================================
  Task 4 - Recursive ArrayQueue Functions
  Lab 09 - Spring 2026 - Data Structures D20
============================================================

--- STEP 1: What I understand about the task ---
Is task mein mujhe ArrayQueue par recursive functions likhne hain.
Queue mein teen operations karne hain:
1. Kisi bhi position par value insert karna
2. Kisi bhi position ki value delete karna
3. Queue palindrome hai ya nahi check karna (sirf queue use karke, koi aur ADT nahi)

--- STEP 2: How I will solve it ---
1. insert(q, value, position):
   - Agar position == 0, directly enqueue karo value, phir baaki queue wapas lagao
   - Warna front element nikalo (dequeue), recursively call karo position-1 ke saath,
     phir woh element wapas queue ke andar daalo
   Progression (q: A->B->C, insert X at pos 1):
   dequeue A -> q: B->C, call insert(q, X, 0)
   insert X at front -> q: X->B->C
   enqueue A -> q: X->B->C->A ... wait, fix ordering:
   Actually: dequeue A, recurse insert(B->C, X, 0), enqueue A
   After recursion: X->B->C, then enqueue A: X->B->C->A (wrong)
   Fix: collect removed elements, insert, then re-enqueue in order.

2. deleteValue(q, position):
   - Position 0 pe element hata do (simply dequeue)
   - Warna front nikalo, recursively delete karo position-1 se, phir front wapas lagao
   Progression (q: A->B->C, delete pos 1 = B):
   dequeue A -> q: B->C, call delete(q, 0)
   dequeue B -> q: C
   enqueue A -> q: C->A

3. isPalindrome(q):
   - Queue ko copy karo
   - Front element nikalo, usi ko baaki elements ke baad compare karo
   - Recursion se andar aao
   - Only queue allowed - to check palindrome, rotate queue and compare ends
   Progression (q: 1->2->1):
   front=1, rotate to get last element, compare. If match, remove both and recurse.

--- STEP 3: Functions I will reuse ---
- enqueue(), dequeue(), front(), isEmpty(), size() queue ke built-in functions.
- isPalindrome mein ek helper getLast() reuse karunga jo queue ko rotate karke last element laata hai.
- insert aur delete mein dequeue/enqueue pattern reuse hota hai.

Progression (delete example): A->B->C  (delete pos 1)
Step 1: dequeue A, delete(B->C, 0) = C, enqueue A -> C->A

--- STEP 4: What I learned ---
Maine seekha ke queue mein random access nahi hoti, isliye position-based operations
mein elements ko temporarily nikalna padta hai.
Palindrome check mein bina extra ADT ke sirf queue rotate karke ho sakta hai.
Recursion mein return sequence zaruri hai taake elements sahi order mein wapas jayein.

--- STEP 5: Skills developed ---
Ab main queue par position-based operations kar sakta hun recursively.
Main queue rotation technique samajh gaya hun.
Main queue-only palindrome check implement kar sakta hun.
============================================================
*/

#include <iostream>
using namespace std;

// ===== Simple ArrayQueue Implementation =====
template <class T>
class ArrayQueue {
private:
    T* data;
    int frontIdx, rearIdx, count, capacity;
public:
    ArrayQueue(int cap = 100) : capacity(cap), frontIdx(0), rearIdx(-1), count(0) {
        data = new T[cap];
    }
    ArrayQueue(const ArrayQueue& other) : capacity(other.capacity),
        frontIdx(other.frontIdx), rearIdx(other.rearIdx), count(other.count) {
        data = new T[capacity];
        for (int i = 0; i < capacity; i++) data[i] = other.data[i];
    }
    ~ArrayQueue() { delete[] data; }

    void enqueue(T val) {
        rearIdx = (rearIdx + 1) % capacity;
        data[rearIdx] = val;
        count++;
    }
    void dequeue() {
        frontIdx = (frontIdx + 1) % capacity;
        count--;
    }
    T front() const { return data[frontIdx]; }
    bool isEmpty() const { return count == 0; }
    int size() const { return count; }
};

// Helper: rotate queue by 1 (move front to back) - recursive
void rotateOne(ArrayQueue<int>& q) {
    int val = q.front();
    q.dequeue();
    q.enqueue(val);
}

// Helper: rotate n times recursively
void rotateN(ArrayQueue<int>& q, int n) {
    if (n == 0) return;
    rotateOne(q);
    rotateN(q, n - 1);
}

// 1. Insert value at given position (0-indexed)
// Strategy: rotate 'position' elements to back, enqueue value, rotate rest back to restore order
// Example: q=1,2,3, insert 99 at pos 1
//   rotateN(q,1) -> q=2,3,1
//   enqueue 99   -> q=2,3,1,99
//   rotateN(q,2) -> q=99,2,3,1 ... hmm
// Better: rotate(position) -> front 'position' items go to back
//   enqueue value -> at back
//   rotate(n - position) -> bring back those original items
// q=1,2,3 n=3, pos=1: rotate(1)->2,3,1; enqueue 99->2,3,1,99; rotate(2)->1,99,2,3 wait
// rotate(n-pos)=rotate(2): first rotate: 3,1,99,2; second rotate: 1,99,2,3 ... no
// Let me use: rotate(position), enqueue, rotate(n-position) in reverse direction
// Simplest proven approach: rotate position times, enqueue value, rotate (n-position) times
void insert(ArrayQueue<int>& q, int value, int position) {
    int n = q.size();
    rotateN(q, position);      // move first 'position' elements to back
    q.enqueue(value);          // add value; it's now after first 'position' original elements
    rotateN(q, n - position);  // cycle remaining original elements back to front
}

// 2. Delete value at given position (0-indexed)
// Strategy: rotate 'position' times (target comes to front), dequeue, rotate back
void deleteValue(ArrayQueue<int>& q, int position) {
    int n = q.size();
    rotateN(q, position);          // element at 'position' is now at front
    q.dequeue();                   // remove it
    rotateN(q, n - position - 1); // restore order of remaining elements
}

// 3. isPalindrome - only queue allowed, no other ADT
// Strategy: compare front with last, remove both, recurse
// We use a mutable copy internally
bool isPalindromeHelper(ArrayQueue<int> q, int sz) {
    if (sz <= 1) return true; // 0 or 1 element is always palindrome

    int firstVal = q.front();
    q.dequeue();

    // Get last value: rotate sz-2 more times (since first is gone, sz-1 elements remain)
    rotateN(q, sz - 2); // last element is now at front
    int lastVal = q.front();
    q.dequeue();

    if (firstVal != lastVal) return false;

    // Recurse on remaining sz-2 elements
    return isPalindromeHelper(q, sz - 2);
}

bool isPalindrome(const ArrayQueue<int>& q) {
    ArrayQueue<int> copy = q; // copy the queue since we need to modify it
    return isPalindromeHelper(copy, copy.size());
}

// Helper to print queue
void printQueue(ArrayQueue<int> q) {
    cout << "Queue (front->back): ";
    while (!q.isEmpty()) {
        cout << q.front() << " ";
        q.dequeue();
    }
    cout << endl;
}

// ===== MAIN =====
int main() {
    cout << "===== Task 4: Recursive ArrayQueue Functions =====" << endl;

    // Test insert
    cout << "\n--- insert ---" << endl;
    ArrayQueue<int> q1;
    q1.enqueue(1); q1.enqueue(2); q1.enqueue(3); // 1->2->3
    printQueue(q1);
    insert(q1, 99, 1); // Insert 99 at position 1 -> 1->99->2->3
    printQueue(q1);    // Expected: 1 99 2 3

    cout << endl;
    ArrayQueue<int> q2;
    q2.enqueue(10); q2.enqueue(20); q2.enqueue(30);
    insert(q2, 5, 0); // Insert at front
    printQueue(q2);    // Expected: 5 10 20 30

    // Test deleteValue
    cout << "\n--- deleteValue ---" << endl;
    ArrayQueue<int> q3;
    q3.enqueue(1); q3.enqueue(2); q3.enqueue(3); q3.enqueue(4);
    printQueue(q3);
    deleteValue(q3, 2); // Delete position 2 (value 3)
    printQueue(q3);     // Expected: 1 2 4

    ArrayQueue<int> q4;
    q4.enqueue(10); q4.enqueue(20); q4.enqueue(30);
    deleteValue(q4, 0); // Delete front
    printQueue(q4);     // Expected: 20 30

    // Test isPalindrome
    cout << "\n--- isPalindrome ---" << endl;
    ArrayQueue<int> q5;
    q5.enqueue(1); q5.enqueue(2); q5.enqueue(3); q5.enqueue(2); q5.enqueue(1);
    cout << "1 2 3 2 1 -> Palindrome: " << (isPalindrome(q5) ? "YES" : "NO") << endl; // YES

    ArrayQueue<int> q6;
    q6.enqueue(1); q6.enqueue(2); q6.enqueue(3);
    cout << "1 2 3     -> Palindrome: " << (isPalindrome(q6) ? "YES" : "NO") << endl; // NO

    ArrayQueue<int> q7;
    q7.enqueue(5); q7.enqueue(5);
    cout << "5 5       -> Palindrome: " << (isPalindrome(q7) ? "YES" : "NO") << endl; // YES

    ArrayQueue<int> q8;
    q8.enqueue(1); q8.enqueue(2); q8.enqueue(2); q8.enqueue(1);
    cout << "1 2 2 1   -> Palindrome: " << (isPalindrome(q8) ? "YES" : "NO") << endl; // YES

    return 0;
}
