/*
============================================================
  Task 5 - Recursive DoublyLinkedList Functions
  Lab 09 - Spring 2026 - Data Structures D20
============================================================

--- STEP 1: What I understand about the task ---
Is task mein mujhe DoublyLinkedList par recursive functions likhne hain.
DoublyLinkedList mein har node ke paas aage (next) aur peeche (prev) ka pointer hota hai.
Teen kaam karne hain:
1. Kisi position par value insert karna
2. Kisi position ki value delete karna
3. List palindrome hai ya nahi check karna

--- STEP 2: How I will solve it ---
1. insert(list, value, position):
   - Agar position == 0, list ke shuruaat mein insert karo
   - Warna list ke current node par kaam karo aur recursion se position-1 tak jao
   Progression: A -> B -> C (insert X at pos 1)
   pos 0 != 1, move to next node (B)
   pos 1 == 1, insert before B -> A -> X -> B -> C

2. deleteValue(list, position):
   - Position 0 par head delete karo
   - Warna recursion se position-1 tak jao aur woh node delete karo
   Progression: A -> B -> C (delete pos 1 = B)
   pos 0 != 1, move to B
   pos 1 == 1, delete B -> A -> C

3. isPalindrome(list):
   - Front pointer aur back pointer use karo
   - Recursion se andar aate jao, comparing front and back values
   - DoublyLinkedList mein yeh asaan hai kyunki prev pointer available hai
   Progression: 1 <-> 2 <-> 3 <-> 2 <-> 1
   Compare head(1) == tail(1) -> yes, move head forward, tail backward
   Compare head(2) == tail(2) -> yes, move inward
   Only 3 left (or none) -> palindrome confirmed

--- STEP 3: Functions I will reuse ---
- DoublyLinkedList ke built-in insertFront(), insertBack(), deleteNode() functions.
- isPalindrome mein front aur back pointers milta hun directly from list.
- Har task mein ek recursive helper function use karunga jo node pointer leta hai.

Node progression (insert at pos 2): 
A <-> B <-> C (head=A, tail=C)
call(A, X, 2) -> call(B, X, 1) -> call(C, X, 0) -> insert before C -> A <-> B <-> X <-> C

--- STEP 4: What I learned ---
Maine seekha ke DoublyLinkedList mein palindrome check karna zyada asaan hai
kyunki hum do direction mein traverse kar sakte hain.
Insert aur delete mein position count karna aur base case set karna zaruri hai.
Doubly linked list mein node delete karne par dono neighbors update karne padte hain.

--- STEP 5: Skills developed ---
Ab main DoublyLinkedList par recursive operations implement kar sakta hun.
Main two-pointer technique (front and back) recursively apply kar sakta hun.
Main linked list insertions/deletions position-based kar sakta hun.
============================================================
*/

#include <iostream>
using namespace std;

// ===== Node for DoublyLinkedList =====
template <class T>
struct DLNode {
    T data;
    DLNode* next;
    DLNode* prev;
    DLNode(T val) : data(val), next(nullptr), prev(nullptr) {}
};

// ===== DoublyLinkedList Implementation =====
template <class T>
class DoublyLinkedList {
public:
    DLNode<T>* head;
    DLNode<T>* tail;
    int sz;

    DoublyLinkedList() : head(nullptr), tail(nullptr), sz(0) {}

    void insertBack(T val) {
        DLNode<T>* node = new DLNode<T>(val);
        if (!tail) {
            head = tail = node;
        } else {
            tail->next = node;
            node->prev = tail;
            tail = node;
        }
        sz++;
    }

    void print() const {
        DLNode<T>* cur = head;
        cout << "List: ";
        while (cur) {
            cout << cur->data;
            if (cur->next) cout << " <-> ";
            cur = cur->next;
        }
        cout << endl;
    }

    int size() const { return sz; }
};

// ===== 1. Insert at position (recursive helper) =====
template <class T>
void insertHelper(DoublyLinkedList<T>& list, DLNode<T>* current, T value, int position) {
    if (position == 0 || current == nullptr) {
        // Insert before 'current' (or at end if current is null)
        DLNode<T>* node = new DLNode<T>(value);
        list.sz++;

        if (current == nullptr) {
            // Insert at end
            if (!list.tail) {
                list.head = list.tail = node;
            } else {
                node->prev = list.tail;
                list.tail->next = node;
                list.tail = node;
            }
        } else if (current == list.head) {
            // Insert before head
            node->next = list.head;
            list.head->prev = node;
            list.head = node;
        } else {
            // Insert before current (in middle)
            DLNode<T>* prevNode = current->prev;
            prevNode->next = node;
            node->prev = prevNode;
            node->next = current;
            current->prev = node;
        }
        return;
    }
    insertHelper(list, current->next, value, position - 1);
}

template <class T>
void insert(DoublyLinkedList<T>& list, T value, int position) {
    insertHelper(list, list.head, value, position);
}

// ===== 2. Delete at position (recursive helper) =====
template <class T>
void deleteHelper(DoublyLinkedList<T>& list, DLNode<T>* current, int position) {
    if (current == nullptr) return; // position out of range

    if (position == 0) {
        // Delete current node
        if (current->prev) current->prev->next = current->next;
        else list.head = current->next; // deleting head

        if (current->next) current->next->prev = current->prev;
        else list.tail = current->prev; // deleting tail

        delete current;
        list.sz--;
        return;
    }
    deleteHelper(list, current->next, position - 1);
}

template <class T>
void deleteValue(DoublyLinkedList<T>& list, int position) {
    deleteHelper(list, list.head, position);
}

// ===== 3. isPalindrome (recursive, using front and back pointers) =====
template <class T>
bool isPalindromeHelper(DLNode<T>* front, DLNode<T>* back, int size) {
    if (size <= 1) return true; // 0 or 1 element left - palindrome

    if (front->data != back->data) return false;

    // Move inward
    return isPalindromeHelper(front->next, back->prev, size - 2);
}

template <class T>
bool isPalindrome(const DoublyLinkedList<T>& list) {
    if (list.sz <= 1) return true;
    return isPalindromeHelper(list.head, list.tail, list.sz);
}

// ===== MAIN =====
int main() {
    cout << "===== Task 5: Recursive DoublyLinkedList Functions =====" << endl;

    // Test insert
    cout << "\n--- insert ---" << endl;
    DoublyLinkedList<int> list1;
    list1.insertBack(1);
    list1.insertBack(2);
    list1.insertBack(3);
    list1.print();          // 1 <-> 2 <-> 3

    insert(list1, 99, 1);   // Insert 99 at position 1
    list1.print();          // Expected: 1 <-> 99 <-> 2 <-> 3

    insert(list1, 0, 0);    // Insert 0 at front
    list1.print();          // Expected: 0 <-> 1 <-> 99 <-> 2 <-> 3

    insert(list1, 100, 5);  // Insert at end (position = size)
    list1.print();          // Expected: 0 <-> 1 <-> 99 <-> 2 <-> 3 <-> 100

    // Test deleteValue
    cout << "\n--- deleteValue ---" << endl;
    DoublyLinkedList<int> list2;
    list2.insertBack(10);
    list2.insertBack(20);
    list2.insertBack(30);
    list2.insertBack(40);
    list2.print();          // 10 <-> 20 <-> 30 <-> 40

    deleteValue(list2, 2);  // Delete position 2 (value 30)
    list2.print();          // Expected: 10 <-> 20 <-> 40

    deleteValue(list2, 0);  // Delete front (value 10)
    list2.print();          // Expected: 20 <-> 40

    // Test isPalindrome
    cout << "\n--- isPalindrome ---" << endl;

    DoublyLinkedList<int> pal1;
    pal1.insertBack(1); pal1.insertBack(2); pal1.insertBack(3);
    pal1.insertBack(2); pal1.insertBack(1);
    pal1.print();
    cout << "isPalindrome: " << (isPalindrome(pal1) ? "YES" : "NO") << endl; // YES

    DoublyLinkedList<int> pal2;
    pal2.insertBack(1); pal2.insertBack(2); pal2.insertBack(3);
    pal2.print();
    cout << "isPalindrome: " << (isPalindrome(pal2) ? "YES" : "NO") << endl; // NO

    DoublyLinkedList<int> pal3;
    pal3.insertBack(5); pal3.insertBack(5);
    pal3.print();
    cout << "isPalindrome: " << (isPalindrome(pal3) ? "YES" : "NO") << endl; // YES

    DoublyLinkedList<int> pal4;
    pal4.insertBack(1); pal4.insertBack(2); pal4.insertBack(2); pal4.insertBack(1);
    pal4.print();
    cout << "isPalindrome: " << (isPalindrome(pal4) ? "YES" : "NO") << endl; // YES

    return 0;
}
