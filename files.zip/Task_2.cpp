/*
============================================================
  Task 2 - Recursive ArrayStack Functions
  Lab 09 - Spring 2026 - Data Structures D20
============================================================

--- STEP 1: What I understand about the task ---
Is task mein mujhe ArrayStack ke saath kaam karne wale recursive functions likhne hain.
Teen kaam karne hain:
1. Prefix expression evaluate karna (e.g., "+ 3 4" = 7)
2. Postfix expression evaluate karna (e.g., "3 4 +" = 7)
3. Tower of Hanoi style stack copy karna - jahan smaller values always upar rahein

--- STEP 2: How I will solve it ---
1. evaluatePrefix: Expression left se right padhta hun.
   - Agar digit mile toh stack mein push karo.
   - Agar operator mile toh stack se do numbers pop karo, operation karo, result push karo.
   - Recursion se har character process hoti hai.
   - Prefix mein operator pehle aata hai: +34 means 3+4

2. evaluatePostfix: Expression left se right padhta hun.
   - Agar digit mile toh stack mein push karo.
   - Agar operator mile toh do values pop karo, operation karo, result wapas push karo.
   - Postfix mein operator baad mein aata hai: 34+ means 3+4

3. copyTOH: Tower of Hanoi rules follow karke stack copy karna.
   - Top element ko directly src se copy nahi kar sakte agar koi bada element neeche ho
   - Helper stack use karke intermediate moves karte hain
   - Recursion se ek ek element sahi jagah rakhte hain

--- STEP 3: Functions I will reuse ---
- push(), pop(), top(), isEmpty() ArrayStack ke built-in functions use karunga.
- evaluatePrefix aur evaluatePostfix mein ek helper applyOp() reuse karunga.
- copyTOH mein hanoi() helper recursive function reuse karunga.

Progression (copyTOH, src has [3,2,1] top=1):
src: 3->2->1(top)  copy: empty  temp: empty
Move 1 from src to copy: src: 3->2  copy: 1  temp: empty
Move 2: need temp, move 1 to temp first: src:3->2  copy:empty  temp:1
Move 2 from src to copy: src:3  copy:2  temp:1
Move 1 from temp to copy: src:3  copy:2->1  temp:empty
...and so on recursively

--- STEP 4: What I learned ---
Maine seekha ke stack-based expression evaluation mein order of operands important hai.
Postfix aur prefix dono mein stack se pop karne ka order matter karta hai (a-b vs b-a).
Tower of Hanoi recursion mein n-1 elements move karna, phir n-th move, phir n-1 wapas.

--- STEP 5: Skills developed ---
Ab main stack se expression evaluate kar sakta hun.
Main Tower of Hanoi jaisi constraint-based problems solve kar sakta hun.
Main recursive stack manipulation samajh gaya hun.
============================================================
*/

#include <iostream>
#include <cstring>
using namespace std;

// ===== Simple ArrayStack Implementation =====
template <class T>
class ArrayStack {
private:
    T* data;
    int topIdx;
    int capacity;
public:
    ArrayStack(int cap = 100) : capacity(cap), topIdx(-1) {
        data = new T[cap];
    }
    ArrayStack(const ArrayStack& other) : capacity(other.capacity), topIdx(other.topIdx) {
        data = new T[capacity];
        for (int i = 0; i <= topIdx; i++) data[i] = other.data[i];
    }
    ~ArrayStack() { delete[] data; }

    void push(T val) {
        if (topIdx < capacity - 1) data[++topIdx] = val;
    }
    void pop() {
        if (topIdx >= 0) topIdx--;
    }
    T top() const { return data[topIdx]; }
    bool isEmpty() const { return topIdx == -1; }
    int size() const { return topIdx + 1; }
};

// ===== Helper: apply operator =====
int applyOp(char op, int a, int b) {
    if (op == '+') return a + b;
    if (op == '-') return a - b;
    if (op == '*') return a * b;
    if (op == '/' && b != 0) return a / b;
    return 0;
}

// 1. Evaluate Prefix Expression recursively
// Prefix: operator comes first, e.g., "+34" means 3+4
// Strategy: use an index pointer to scan left to right
// Each recursive call consumes one token and returns its value
int evalPrefixAt(char* expr, int& idx) {
    // Skip spaces
    while (expr[idx] == ' ') idx++;

    if (expr[idx] == '\0') return 0;

    char c = expr[idx++];

    if (c >= '0' && c <= '9') {
        return c - '0'; // digit: return its value directly
    }

    // It's an operator: get left and right operands recursively
    int left  = evalPrefixAt(expr, idx);
    int right = evalPrefixAt(expr, idx);
    return applyOp(c, left, right);
}

int evaluatePrefix(char* expression, const ArrayStack<int> s) {
    int idx = 0;
    return evalPrefixAt(expression, idx);
}

// 2. Evaluate Postfix Expression recursively
// Postfix: operands first, operator at end, e.g., "34+" means 3+4
int evaluatePostfix(char* expression, ArrayStack<int> s) {
    if (*expression == '\0') return s.top(); // base case

    char c = *expression;

    if (c == ' ') return evaluatePostfix(expression + 1, s);

    if (c >= '0' && c <= '9') {
        s.push(c - '0');
        return evaluatePostfix(expression + 1, s);
    }

    if (c == '+' || c == '-' || c == '*' || c == '/') {
        int b = s.top(); s.pop();
        int a = s.top(); s.pop();
        s.push(applyOp(c, a, b));
        return evaluatePostfix(expression + 1, s);
    }

    return evaluatePostfix(expression + 1, s);
}

// 3. Tower of Hanoi Stack Copy
// Rules: smaller on top, can't place larger on smaller
// Helper: move n disks from src to dst using temp
void hanoiMove(int n, ArrayStack<int>& src, ArrayStack<int>& dst, ArrayStack<int>& temp) {
    if (n == 0) return;
    // Move n-1 from src to temp (using dst as temp)
    hanoiMove(n - 1, src, temp, dst);
    // Move the nth (largest remaining) from src to dst
    dst.push(src.top());
    src.pop();
    // Move n-1 from temp to dst (using src as temp)
    hanoiMove(n - 1, temp, dst, src);
}

void copyTOH(ArrayStack<int> src, ArrayStack<int>& copy) {
    ArrayStack<int> temp;
    int n = src.size();
    // Move all from src to copy using Hanoi rules
    hanoiMove(n, src, copy, temp);
}

// ===== MAIN =====
int main() {
    cout << "===== Task 2: Recursive ArrayStack Functions =====" << endl;

    // Test evaluatePostfix
    cout << "\n--- evaluatePostfix ---" << endl;
    ArrayStack<int> emptyStack;
    char post1[] = "34+";       // 3+4 = 7
    char post2[] = "53-";       // 5-3 = 2
    char post3[] = "23*";       // 2*3 = 6
    char post4[] = "82/";       // 8/2 = 4
    cout << "34+   = " << evaluatePostfix(post1, emptyStack) << " (expected 7)" << endl;
    cout << "53-   = " << evaluatePostfix(post2, emptyStack) << " (expected 2)" << endl;
    cout << "23*   = " << evaluatePostfix(post3, emptyStack) << " (expected 6)" << endl;
    cout << "82/   = " << evaluatePostfix(post4, emptyStack) << " (expected 4)" << endl;

    // Test evaluatePrefix
    cout << "\n--- evaluatePrefix ---" << endl;
    ArrayStack<int> emptyStack2;
    char pre1[] = "+34";        // 3+4 = 7
    char pre2[] = "-53";        // 5-3 = 2
    char pre3[] = "*23";        // 2*3 = 6
    cout << "+34   = " << evaluatePrefix(pre1, emptyStack2) << " (expected 7)" << endl;
    cout << "-53   = " << evaluatePrefix(pre2, emptyStack2) << " (expected 2)" << endl;
    cout << "*23   = " << evaluatePrefix(pre3, emptyStack2) << " (expected 6)" << endl;

    // Test copyTOH
    cout << "\n--- copyTOH ---" << endl;
    ArrayStack<int> src;
    // Push in reverse order (largest first) so smallest is on top
    src.push(5); src.push(4); src.push(3); src.push(2); src.push(1); // top=1
    ArrayStack<int> copiedStack;
    copyTOH(src, copiedStack);

    cout << "Copied stack (top to bottom): ";
    while (!copiedStack.isEmpty()) {
        cout << copiedStack.top() << " ";
        copiedStack.pop();
    }
    cout << endl; // Expected: 1 2 3 4 5

    return 0;
}
