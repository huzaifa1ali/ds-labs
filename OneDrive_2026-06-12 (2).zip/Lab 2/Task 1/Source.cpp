#include <iostream>
using namespace std;

#include "AbstractArray.h"
#include "MyArray.h"


void read(AbstractArray* A, istream& in, int n)
{
    int value;
    for (int i = 0; i < n; i++)
    {
        in >> value;
        A->add(value);
    }
}

void display(AbstractArray* A, ostream& out)
{
    for (int i = 0; i < A->getSize(); i++)
    {
        out << A->get(i) << " ";
    }
    out << endl;
}

void copy(AbstractArray* src, AbstractArray* dst)
{
    for (int i = 0; i < src->getSize(); i++)
    {
        dst->add(src->get(i));
    }
}

void insert(AbstractArray* src, AbstractArray* dst, int pos)
{
    int size = dst->getSize();

    for (int i = size - 1; i >= pos; i--)
    {
        dst->set(i + src->getSize(), dst->get(i));
    }

    for (int i = 0; i < src->getSize(); i++)
    {
        dst->set(pos + i, src->get(i));
    }

    dst->setSize(size + src->getSize());
}

void shiftLeft(AbstractArray* aa, int pos)
{
    for (int i = pos; i < aa->getSize() - 1; i++)
    {
        aa->set(i, aa->get(i + 1));
    }

    aa->setSize(aa->getSize() - 1);
}

void shiftRight(AbstractArray* aa, int pos)
{
    int size = aa->getSize();

    for (int i = size - 1; i >= pos; i--)
    {
        aa->set(i + 1, aa->get(i));
    }

    aa->set(pos, 0);

    aa->setSize(size + 1);
}

void stats(AbstractArray* AA, int& max, float& average)
{
    int sum = 0;
    max = AA->get(0);

    for (int i = 0; i < AA->getSize(); i++)
    {
        int val = AA->get(i);

        if (val > max)
            max = val;

        sum += val;
    }

    average = (float)sum / AA->getSize();
}



int main()
{
    AbstractArray* A = new AbstractArray(MAX_SIZE);

    int n = 0;
    cout << "please select a number between 1 and " << MAX_SIZE << ": ";
    cin >> n;

    read(A, cin, n);

    cout << "Array A Values: ";
    display(A, cout);

    AbstractArray* B = new AbstractArray(MAX_SIZE);
    copy(A, B);

    cout << "Array B Values: ";
    display(B, cout);

    AbstractArray* C = new AbstractArray(MAX_SIZE);

    C->add(9);
    C->add(7);
    C->add(5);

    insert(A, C, 2);

    cout << "Array C Values: ";
    display(C, cout);

    shiftLeft(C, 2);

    cout << "Array C Values: ";
    display(C, cout);

    shiftRight(C, 2);

    cout << "Array C Values: ";
    display(C, cout);

    int mx = 0;
    float ag = 0.0;

    stats(C, mx, ag);

    cout << "Array C Values: ";
    display(C, cout);

    cout << "Average is " << ag << " maximum is " << mx << endl;

    return 0;
}