#ifndef MYSTACK_H
#define MYSTACK_H

#include "Stack.h"
#include <iostream>
using namespace std;

void read(Stack* s, istream& in, int n);
void display(Stack* s, ostream& out);
void copy(Stack* src, Stack* dst);
void insert(Stack* src, Stack* dst, int pos);
void shiftLeft(Stack* s, int pos);
void shiftRight(Stack* s, int pos);
void stats(Stack* s, int& max, float& average);

#endif#pragma once
