#include <iostream>
using namespace std;

#include "Stack.h"
#include "MyStack.h"

void read(Stack* s, istream& in, int n)
{
    int value;
    for (int i = 0; i < n; i++)
    {
        in >> value;
        s->push(value);
    }
}

void display(Stack* s, ostream& out)
{
    for (int i = 0; i < s->getSize(); i++)
    {
        out << s->peek(i) << " ";
    }
    out << endl;
}

void copy(Stack* src, Stack* dst)
{
    for (int i = 0; i < src->getSize(); i++)
    {
        dst->push(src->peek(i));
    }
}

void insert(Stack* src, Stack* dst, int pos)
{
    int size = dst->getSize();

    for (int i = size - 1; i >= pos; i--)
    {
        dst->set(i + src->getSize(), dst->peek(i));
    }

    for (int i = 0; i < src->getSize(); i++)
    {
        dst->set(pos + i, src->peek(i));
    }

    dst->setSize(size + src->getSize());
}

void shiftLeft(Stack* s, int pos)
{
    for (int i = pos; i < s->getSize() - 1; i++)
    {
        s->set(i, s->peek(i + 1));
    }

    s->setSize(s->getSize() - 1);
}

void shiftRight(Stack* s, int pos)
{
    int size = s->getSize();

    for (int i = size - 1; i >= pos; i--)
    {
        s->set(i + 1, s->peek(i));
    }

    s->set(pos, 0);

    s->setSize(size + 1);
}

void stats(Stack* s, int& max, float& average)
{
    int sum = 0;
    max = s->peek(0);

    for (int i = 0; i < s->getSize(); i++)
    {
        int val = s->peek(i);

        if (val > max)
            max = val;

        sum += val;
    }

    average = (float)sum / s->getSize();
}


int main()
{
    Stack* A = new Stack(MAX_SIZE);

    int n = 0;
    cout << "please select a number between 1 and " << MAX_SIZE << ": ";
    cin >> n;

    read(A, cin, n);

    cout << "Stack A Values: ";
    display(A, cout);

    Stack* B = new Stack(MAX_SIZE);
    copy(A, B);

    cout << "Stack B Values: ";
    display(B, cout);

    Stack* C = new Stack(MAX_SIZE);

    C->push(9);
    C->push(7);
    C->push(5);

    insert(A, C, 2);

    cout << "Stack C Values: ";
    display(C, cout);

    shiftLeft(C, 2);

    cout << "Stack C Values: ";
    display(C, cout);

    shiftRight(C, 2);

    cout << "Stack C Values: ";
    display(C, cout);

    int mx = 0;
    float ag = 0.0;

    stats(C, mx, ag);

    cout << "Stack C Values: ";
    display(C, cout);

    cout << "Average is " << ag << " maximum is " << mx << endl;

    return 0;
}