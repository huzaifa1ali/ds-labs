#pragma once
#ifndef MYSTACK_H
#define MYSTACK_H

#include "Stack.h"
#include <iostream>
using namespace std;

void readFile(Stack* s, const string& filename); // read words from file
void display(Stack* s);
void reverseCopy(Stack* src, Stack* dst);
void removeDuplicates(Stack* s);
void countFrequency(Stack* s);

#endif