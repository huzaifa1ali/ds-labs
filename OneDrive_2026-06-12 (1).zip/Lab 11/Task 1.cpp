#include <iostream>
using namespace std;

void countWords(const char* sentence)
{
    static int words = 0;
    static bool inWord = false;

    if (*sentence == '\0')
    {
        cout << "Words: " << words << endl;
        words = 0;
        inWord = false;
        return;
    }

    if (*sentence != ' ' && inWord == false)
    {
        words++;
        inWord = true;
    }

    if (*sentence == ' ')
        inWord = false;

    countWords(sentence + 1);
}

void countCharaters(const char* sentence)
{
    static int count = 0;

    if (*sentence == '\0')
    {
        cout << "Characters: " << count << endl;
        count = 0;
        return;
    }

    count++;

    countCharaters(sentence + 1);
}

void reverse(char*& sentence)
{
    static int start = 0;
    static int end = -1;

    if (end == -1)
    {
        int i = 0;

        while (sentence[i] != '\0')
            i++;

        end = i - 1;
    }

    if (start >= end)
    {
        start = 0;
        end = -1;
        return;
    }

    char temp = sentence[start];
    sentence[start] = sentence[end];
    sentence[end] = temp;

    start++;
    end--;

    reverse(sentence);
}

void reverseWords(char*& sentence)
{
    static bool done = false;

    if (!done)
    {
        reverse(sentence);
        done = true;
    }

    static int i = 0;
    static int start = 0;

    if (sentence[i] == ' ' || sentence[i] == '\0')
    {
        int left = start;
        int right = i - 1;

        while (left < right)
        {
            char temp = sentence[left];
            sentence[left] = sentence[right];
            sentence[right] = temp;

            left++;
            right--;
        }

        start = i + 1;
    }

    if (sentence[i] == '\0')
    {
        i = 0;
        start = 0;
        done = false;
        return;
    }

    i++;

    reverseWords(sentence);
}

void convert(char* sentence)
{
    if (*sentence == '\0')
        return;

    if (*sentence >= 'a' && *sentence <= 'z')
        *sentence = *sentence - 32;

    else if (*sentence >= 'A' && *sentence <= 'Z')
        *sentence = *sentence + 32;

    convert(sentence + 1);
}

int main()
{
    char arr1[] = "Hello World From Recursion";
    char arr2[] = "AbCdEfG";

    char* s1 = arr1;

    cout << "Original: " << s1 << endl;

    countWords(s1);
    countCharaters(s1);

    reverse(s1);
    cout << "Character Reverse: " << s1 << endl;

    reverse(s1);

    reverseWords(s1);
    cout << "Word Reverse: " << s1 << endl;

    cout << "Before Convert: " << arr2 << endl;
    convert(arr2);
    cout << "After Convert: " << arr2 << endl;

    return 0;
}