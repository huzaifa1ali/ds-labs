#include <iostream>
using namespace std;

template <class T>
class ArrayQueue
{
    T* arr;
    int front;
    int rear;
    int count;
    int size;

public:
    ArrayQueue(int s = 100)
    {
        size = s;
        arr = new T[size];
        front = 0;
        rear = -1;
        count = 0;
    }

    void enqueue(T value)
    {
        rear = (rear + 1) % size;
        arr[rear] = value;
        count++;
    }

    void dequeue()
    {
        front = (front + 1) % size;
        count--;
    }

    T Front() const
    {
        return arr[front];
    }

    bool isEmpty() const
    {
        return count == 0;
    }

    int getCount() const
    {
        return count;
    }

    void display()
    {
        displayRecursive(0);
        cout << endl;
    }

    void displayRecursive(int i)
    {
        if (i == count)
            return;

        cout << arr[(front + i) % size] << " ";

        displayRecursive(i + 1);
    }
};

void insert(ArrayQueue<int>& q, int value, int position)
{
    static int i = 0;
    static int n = q.getCount();

    if (i == n)
    {
        q.enqueue(value);

        i = 0;
        n = q.getCount() - 1;
        return;
    }

    int temp = q.Front();
    q.dequeue();

    if (i == position)
        q.enqueue(value);

    q.enqueue(temp);

    i++;

    insert(q, value, position);
}

void deleteValue(ArrayQueue<int>& q, int position)
{
    static int i = 0;
    static int n = q.getCount();

    if (i == n)
    {
        i = 0;
        n = q.getCount();
        return;
    }

    int temp = q.Front();
    q.dequeue();

    if (i != position)
        q.enqueue(temp);

    i++;

    deleteValue(q, position);
}

bool isPalindrome(const ArrayQueue<int>& q)
{
    static int i = 0;

    int n = q.getCount();

    if (i >= n / 2)
    {
        i = 0;
        return true;
    }

    int left = q.getValue(i);
    int right = q.getValue(n - i - 1);

    if (left != right)
    {
        i = 0;
        return false;
    }

    i++;

    return isPalindrome(q);
}

int main()
{
    ArrayQueue<int> q;

    q.enqueue(1);
    q.enqueue(2);
    q.enqueue(3);
    q.enqueue(2);
    q.enqueue(1);

    cout << "Original Queue: ";
    q.display();

    insert(q, 9, 2);

    cout << "After Insert: ";
    q.display();

    deleteValue(q, 2);

    cout << "After Delete: ";
    q.display();

    if (isPalindrome(q))
        cout << "Queue is Palindrome" << endl;
    else
        cout << "Queue is Not Palindrome" << endl;

    return 0;
}