#include <iostream>
using namespace std;

template <class T>
class Node
{
public:
    T data;
    Node<T>* next;
    Node<T>* prev;

    Node(T value)
    {
        data = value;
        next = NULL;
        prev = NULL;
    }
};

template <class T>
class DoublyLinkedList
{
public:
    Node<T>* head;
    Node<T>* tail;

    DoublyLinkedList()
    {
        head = NULL;
        tail = NULL;
    }

    void insertAtEnd(T value)
    {
        Node<T>* newNode = new Node<T>(value);

        if (head == NULL)
        {
            head = tail = newNode;
            return;
        }

        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }

    void display(Node<T>* temp)
    {
        if (temp == NULL)
        {
            cout << endl;
            return;
        }

        cout << temp->data << " ";
        display(temp->next);
    }
};

void insert(DoublyLinkedList<int>& list, int value, int position)
{
    static Node<int>* curr = list.head;
    static int i = 0;

    if (position == 0 && list.head == NULL)
    {
        Node<int>* newNode = new Node<int>(value);
        list.head = list.tail = newNode;
        return;
    }

    if (i == position)
    {
        Node<int>* newNode = new Node<int>(value);

        if (curr == list.head)
        {
            newNode->next = list.head;
            list.head->prev = newNode;
            list.head = newNode;
        }
        else
        {
            newNode->next = curr;
            newNode->prev = curr->prev;

            curr->prev->next = newNode;
            curr->prev = newNode;
        }

        curr = list.head;
        i = 0;
        return;
    }

    if (curr == NULL)
    {
        Node<int>* newNode = new Node<int>(value);

        list.tail->next = newNode;
        newNode->prev = list.tail;
        list.tail = newNode;

        curr = list.head;
        i = 0;
        return;
    }

    curr = curr->next;
    i++;

    insert(list, value, position);
}

void deleteValue(DoublyLinkedList<int>& list, int position)
{
    static Node<int>* curr = list.head;
    static int i = 0;

    if (curr == NULL)
    {
        curr = list.head;
        i = 0;
        return;
    }

    if (i == position)
    {
        if (curr == list.head && curr == list.tail)
        {
            list.head = list.tail = NULL;
        }
        else if (curr == list.head)
        {
            list.head = curr->next;
            list.head->prev = NULL;
        }
        else if (curr == list.tail)
        {
            list.tail = curr->prev;
            list.tail->next = NULL;
        }
        else
        {
            curr->prev->next = curr->next;
            curr->next->prev = curr->prev;
        }

        delete curr;

        curr = list.head;
        i = 0;
        return;
    }

    curr = curr->next;
    i++;

    deleteValue(list, position);
}

bool checkPalindrome(Node<int>* left, Node<int>* right, int count)
{
    if (count <= 0)
        return true;

    if (left->data != right->data)
        return false;

    return checkPalindrome(left->next, right->prev, count - 2);
}

int countNodes(Node<int>* temp)
{
    if (temp == NULL)
        return 0;

    return 1 + countNodes(temp->next);
}

bool isPalindrome(const DoublyLinkedList<int>& list)
{
    int count = countNodes(list.head);

    return checkPalindrome(list.head, list.tail, count);
}

int main()
{
    DoublyLinkedList<int> list;

    list.insertAtEnd(1);
    list.insertAtEnd(2);
    list.insertAtEnd(3);
    list.insertAtEnd(2);
    list.insertAtEnd(1);

    cout << "Original List: ";
    list.display(list.head);

    insert(list, 9, 2);

    cout << "After Insert: ";
    list.display(list.head);

    deleteValue(list, 2);

    cout << "After Delete: ";
    list.display(list.head);

    if (isPalindrome(list))
        cout << "List is Palindrome" << endl;
    else
        cout << "List is Not Palindrome" << endl;

    return 0;
}