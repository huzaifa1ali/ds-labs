#include <iostream>
using namespace std;

template <class T>
class Node
{
public:
    T data;
    Node* left;
    Node* right;

    Node(T value)
    {
        data = value;
        left = NULL;
        right = NULL;
    }
};

template <class T>
void insert(Node<T>*& root, T value)
{
    if (root == NULL)
    {
        root = new Node<T>(value);
        return;
    }

    if (value < root->data)
        insert(root->left, value);
    else
        insert(root->right, value);
}

template <class T>
int height(Node<T>* treeRoot)
{
    if (treeRoot == NULL)
        return -1;

    int leftHeight = height(treeRoot->left);
    int rightHeight = height(treeRoot->right);

    if (leftHeight > rightHeight)
        return leftHeight + 1;

    return rightHeight + 1;
}

template <class T>
int countNodes(Node<T>* treeRoot)
{
    if (treeRoot == NULL)
        return 0;

    return 1 + countNodes(treeRoot->left)
        + countNodes(treeRoot->right);
}

template <class T>
int countLeaves(Node<T>* treeRoot)
{
    if (treeRoot == NULL)
        return 0;

    if (treeRoot->left == NULL &&
        treeRoot->right == NULL)
        return 1;

    return countLeaves(treeRoot->left)
        + countLeaves(treeRoot->right);
}

template <class T>
Node<T>* copyTree(Node<T>* treeRoot)
{
    if (treeRoot == NULL)
        return NULL;

    Node<T>* newNode = new Node<T>(treeRoot->data);

    newNode->left = copyTree(treeRoot->left);
    newNode->right = copyTree(treeRoot->right);

    return newNode;
}

template <class T>
void inorderDisplay(Node<T>* root)
{
    if (root == NULL)
        return;

    inorderDisplay(root->left);

    cout << root->data << " ";

    inorderDisplay(root->right);
}

template <class T>
bool preorderSearch(Node<T>* root, T value)
{
    if (root == NULL)
        return false;

    if (root->data == value)
        return true;

    return preorderSearch(root->left, value)
        || preorderSearch(root->right, value);
}

template <class T>
bool BSTSearch(Node<T>* root, T value)
{
    if (root == NULL)
        return false;

    if (root->data == value)
        return true;

    if (value < root->data)
        return BSTSearch(root->left, value);

    return BSTSearch(root->right, value);
}

int main()
{
    Node<int>* root = NULL;

    insert(root, 50);
    insert(root, 30);
    insert(root, 70);
    insert(root, 20);
    insert(root, 40);
    insert(root, 60);
    insert(root, 80);

    cout << "Inorder Display: ";
    inorderDisplay(root);
    cout << endl;

    cout << "Height: "
        << height(root) << endl;

    cout << "Total Nodes: "
        << countNodes(root) << endl;

    cout << "Leaf Nodes: "
        << countLeaves(root) << endl;

    Node<int>* copyRoot = copyTree(root);

    cout << "Copied Tree Inorder: ";
    inorderDisplay(copyRoot);
    cout << endl;

    if (preorderSearch(root, 60))
        cout << "60 Found using Preorder Search" << endl;
    else
        cout << "60 Not Found" << endl;

    if (BSTSearch(root, 80))
        cout << "80 Found using BST Search" << endl;
    else
        cout << "80 Not Found" << endl;

    return 0;
}