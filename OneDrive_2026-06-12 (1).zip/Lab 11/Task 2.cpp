#include <iostream>
using namespace std;

template <class T>
class ArrayStack
{
    T* arr;
    int topIndex;
    int size;

public:
    ArrayStack(int s = 100)
    {
        size = s;
        arr = new T[size];
        topIndex = -1;
    }

    void push(T value)
    {
        arr[++topIndex] = value;
    }

    void pop()
    {
        if (topIndex >= 0)
            topIndex--;
    }

    T top() const
    {
        return arr[topIndex];
    }

    bool isEmpty() const
    {
        return topIndex == -1;
    }

    int getTop() const
    {
        return topIndex;
    }

    void display()
    {
        for (int i = topIndex; i >= 0; i--)
            cout << arr[i] << " ";

        cout << endl;
    }
};

int apply(int a, int b, char op)
{
    if (op == '+')
        return a + b;

    if (op == '-')
        return a - b;

    if (op == '*')
        return a * b;

    if (op == '/')
        return a / b;

    return 0;
}

int evaluatePrefix(char* expression, ArrayStack<int> s)
{
    static int i = -1;

    if (i == -1)
    {
        int len = 0;

        while (expression[len] != '\0')
            len++;

        i = len - 1;
    }

    if (i < 0)
    {
        int ans = s.top();
        i = -1;
        return ans;
    }

    char ch = expression[i];

    if (ch >= '0' && ch <= '9')
    {
        s.push(ch - '0');
    }
    else
    {
        int a = s.top();
        s.pop();

        int b = s.top();
        s.pop();

        s.push(apply(a, b, ch));
    }

    i--;

    return evaluatePrefix(expression, s);
}

int evaluatePostfix(char* expression, ArrayStack<int> s)
{
    static int i = 0;

    if (expression[i] == '\0')
    {
        int ans = s.top();
        i = 0;
        return ans;
    }

    char ch = expression[i];

    if (ch >= '0' && ch <= '9')
    {
        s.push(ch - '0');
    }
    else
    {
        int b = s.top();
        s.pop();

        int a = s.top();
        s.pop();

        s.push(apply(a, b, ch));
    }

    i++;

    return evaluatePostfix(expression, s);
}

void copyTOH(ArrayStack<int> src, ArrayStack<int>& copy)
{
    static ArrayStack<int> temp(100);

    if (src.isEmpty())
    {
        while (!temp.isEmpty())
        {
            copy.push(temp.top());
            temp.pop();
        }

        return;
    }

    int value = src.top();
    src.pop();

    copyTOH(src, copy);

    temp.push(value);
}

int main()
{
    char prefix[] = "-+7*45+20";
    char postfix[] = "745*+20+-";

    ArrayStack<int> s1;
    ArrayStack<int> s2;

    cout << "Prefix Result: "
        << evaluatePrefix(prefix, s1) << endl;

    cout << "Postfix Result: "
        << evaluatePostfix(postfix, s2) << endl;

    ArrayStack<int> original;
    ArrayStack<int> copied;

    original.push(5);
    original.push(4);
    original.push(3);
    original.push(2);
    original.push(1);

    cout << "Original Stack:" << endl;
    original.display();

    copyTOH(original, copied);

    cout << "Copied Stack:" << endl;
    copied.display();

    return 0;
}