/*
 * Task 2: MaxHeap Class Implementation
 *
 * UNDERSTANDING:
 * A MaxHeap is a complete binary tree stored as an array where every parent
 * node is >= its children. The largest element is always at index 0 (root).
 * All heap operations maintain this property using heapify procedures.
 *
 * SOLUTION STEPS:
 * 1. insert: Add value at end, bubble up (compare with parent, swap if greater)
 * 2. remove: Find value, replace with last element, remove last, then heapify down
 * 3. search: Linear scan through array
 * 4. heapsort: Repeatedly extract max to produce sorted array
 * 5. maxHeapify: Fix heap property downward from index i
 * 6. buildHeap: Heapify from last non-leaf to root
 * 7. inorderDisplay: Simulate inorder via array traversal
 *
 * FUNCTIONS REUSED:
 * - insert() reuses maxHeapify() indirectly (bubble-up is inverse of heapify)
 * - remove() reuses maxHeapify() to restore heap after removal
 * - heapsort() reuses maxHeapify()
 * - buildHeap() reuses maxHeapify() on all non-leaf nodes
 *
 * PROGRESSION EXAMPLE (insert 10, 20, 15):
 *   Insert 10: [10]
 *   Insert 20: [10, 20] => bubble up => [20, 10]
 *   Insert 15: [20, 10, 15] => bubble up 15 with parent 20 => no swap => [20, 10, 15]
 *
 * LEARNING:
 * MaxHeap gives O(log n) insert and remove, O(1) max access.
 * Array representation is memory-efficient; parent(i) = (i-1)/2, children = 2i+1, 2i+2.
 *
 * SKILLS DEVELOPED:
 * Heap operations, priority-based data retrieval, heapsort algorithm.
 * Can now build priority queues, scheduling systems, and top-k element finders.
 */

#include <iostream>
#include <stdexcept>
using namespace std;

template <class T>
class MaxHeap {
public:
    MaxHeap() : capacity(10), size(0) {
        array = new T[capacity];
    }

    MaxHeap(const MaxHeap& mh) : capacity(mh.capacity), size(mh.size) {
        array = new T[capacity];
        for (int i = 0; i < size; i++)
            array[i] = mh.array[i];
    }

    const MaxHeap& operator=(const MaxHeap& mh) {
        if (this != &mh) {
            delete[] array;
            capacity = mh.capacity;
            size = mh.size;
            array = new T[capacity];
            for (int i = 0; i < size; i++)
                array[i] = mh.array[i];
        }
        return *this;
    }

    ~MaxHeap() { delete[] array; }

    void insert(const T& value) {
        if (isFull()) resize();
        array[size++] = value;
        bubbleUp(size - 1);
    }

    void remove(const T& value) {
        int idx = findIndex(value);
        if (idx == -1) { cout << "Value not found.\n"; return; }
        array[idx] = array[--size];
        maxHeapify(idx);
        bubbleUp(idx);
    }

    bool search(const T& value) const {
        for (int i = 0; i < size; i++)
            if (array[i] == value) return true;
        return false;
    }

    void heapsort() {
        MaxHeap<T> temp = *this;
        cout << "Sorted (descending): ";
        while (temp.size > 0) {
            cout << temp.array[0] << " ";
            temp.array[0] = temp.array[--temp.size];
            temp.maxHeapify(0);
        }
        cout << endl;
    }

    bool isEmpty() const { return size == 0; }
    bool isFull() const  { return size == capacity; }

    void inorderDisplay() const {
        cout << "Heap array: ";
        for (int i = 0; i < size; i++)
            cout << array[i] << " ";
        cout << endl;
    }

protected:
    T* array;
    int capacity;
    int size;

    void maxHeapify(int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        if (left < size && array[left] > array[largest]) largest = left;
        if (right < size && array[right] > array[largest]) largest = right;
        if (largest != i) {
            swap(array[i], array[largest]);
            maxHeapify(largest);
        }
    }

    void buildHeap() {
        for (int i = size / 2 - 1; i >= 0; i--)
            maxHeapify(i);
    }

    void bubbleUp(int i) {
        while (i > 0) {
            int parent = (i - 1) / 2;
            if (array[i] > array[parent]) {
                swap(array[i], array[parent]);
                i = parent;
            } else break;
        }
    }

    void resize() {
        capacity *= 2;
        T* newArr = new T[capacity];
        for (int i = 0; i < size; i++)
            newArr[i] = array[i];
        delete[] array;
        array = newArr;
    }

    int findIndex(const T& value) const {
        for (int i = 0; i < size; i++)
            if (array[i] == value) return i;
        return -1;
    }
};

int main() {
    MaxHeap<int> heap;
    int values[] = {10, 20, 15, 30, 5};
    cout << "Inserting: 10 20 15 30 5" << endl;
    for (int v : values)
        heap.insert(v);

    heap.inorderDisplay();
    cout << "Search 15: " << (heap.search(15) ? "Found" : "Not Found") << endl;
    heap.remove(20);
    cout << "After removing 20: ";
    heap.inorderDisplay();
    heap.heapsort();
    return 0;
}
