/*
 * Task 3: User ID-Password System using MaxHeap + AVLTree
 *
 * UNDERSTANDING:
 * This task combines two ADTs:
 * - MaxHeap stores sorted user IDs (strings sorted lexicographically)
 * - AVLTree stores ID-Password pairs as {"userID", "password"} string arrays
 *   sorted by ID for fast lookup
 * The system provides a menu for add/remove/search/display operations.
 *
 * SOLUTION STEPS:
 * 1. Reuse MaxHeap<string> for ID storage
 * 2. Reuse AVLTree (Node with string[2] data) for password storage
 * 3. insert(): Add to both MaxHeap and AVLTree
 * 4. remove(): Delete from MaxHeap and AVLTree using userID
 * 5. search(): Use AVLTree to find password by ID
 * 6. display(): Walk AVLTree inorder to print ID-Password table
 *
 * FUNCTIONS REUSED:
 * - MaxHeap::insert(), MaxHeap::remove(), MaxHeap::search() from Task 2
 * - AVLTree insert(), deleteNode(), BST search using ID comparison
 *
 * PROGRESSION EXAMPLE:
 *   Add (user1, pass1): MaxHeap[user1], AVL{user1->pass1}
 *   Add (user2, pass2): MaxHeap[user2, user1], AVL{user1->pass1, user2->pass2}
 *   Search user1: AVL traversal -> "pass1"
 *   Remove user1: MaxHeap[user2], AVL{user2->pass2}
 *
 * LEARNING:
 * Real-world auth systems separate identity (heap for quick max/sorted access)
 * from credential storage (AVL for O(log n) lookup). Using two complementary
 * structures allows efficient operations across different access patterns.
 *
 * SKILLS DEVELOPED:
 * Combining multiple ADTs to model real-world systems.
 * Can now build credential management, user registries, and indexed databases.
 */

#include <iostream>
#include <string>
using namespace std;

// ========== MaxHeap for IDs ==========
template <class T>
class MaxHeap {
public:
    MaxHeap() : capacity(10), size(0) { array = new T[capacity]; }
    ~MaxHeap() { delete[] array; }

    void insert(const T& value) {
        if (size == capacity) resize();
        array[size++] = value;
        bubbleUp(size - 1);
    }

    void remove(const T& value) {
        int idx = findIndex(value);
        if (idx == -1) return;
        array[idx] = array[--size];
        if (idx < size) {
            maxHeapify(idx);
            bubbleUp(idx);
        }
    }

    bool search(const T& value) const {
        for (int i = 0; i < size; i++)
            if (array[i] == value) return true;
        return false;
    }

    void display() const {
        for (int i = 0; i < size; i++) cout << array[i] << " ";
        cout << endl;
    }

    bool isEmpty() const { return size == 0; }

protected:
    T* array;
    int capacity;
    int size;

    void maxHeapify(int i) {
        int largest = i, left = 2*i+1, right = 2*i+2;
        if (left < size && array[left] > array[largest]) largest = left;
        if (right < size && array[right] > array[largest]) largest = right;
        if (largest != i) { swap(array[i], array[largest]); maxHeapify(largest); }
    }

    void bubbleUp(int i) {
        while (i > 0) {
            int p = (i - 1) / 2;
            if (array[i] > array[p]) { swap(array[i], array[p]); i = p; }
            else break;
        }
    }

    void resize() {
        capacity *= 2;
        T* newArr = new T[capacity];
        for (int i = 0; i < size; i++) newArr[i] = array[i];
        delete[] array; array = newArr;
    }

    int findIndex(const T& value) const {
        for (int i = 0; i < size; i++) if (array[i] == value) return i;
        return -1;
    }
};

// ========== AVL Tree for ID-Password pairs ==========
struct PairNode {
    string data[2]; // data[0]=ID, data[1]=Password
    PairNode* left;
    PairNode* right;
    PairNode(string id, string pw) : left(nullptr), right(nullptr) {
        data[0] = id; data[1] = pw;
    }
};

int avlHeight(PairNode* n) {
    if (!n) return 0;
    int l = avlHeight(n->left), r = avlHeight(n->right);
    return 1 + (l > r ? l : r);
}

int avlBalance(PairNode* n) {
    if (!n) return 0;
    return avlHeight(n->left) - avlHeight(n->right);
}

PairNode* avlLeftRotate(PairNode* root) {
    PairNode* nr = root->right;
    root->right = nr->left;
    nr->left = root;
    return nr;
}

PairNode* avlRightRotate(PairNode* root) {
    PairNode* nr = root->left;
    root->left = nr->right;
    nr->right = root;
    return nr;
}

PairNode* avlInsert(PairNode* root, string id, string pw) {
    if (!root) return new PairNode(id, pw);
    if (id < root->data[0]) root->left = avlInsert(root->left, id, pw);
    else if (id > root->data[0]) root->right = avlInsert(root->right, id, pw);
    else { root->data[1] = pw; return root; } // update password if ID exists

    int bf = avlBalance(root);
    if (bf > 1 && id < root->left->data[0]) return avlRightRotate(root);
    if (bf < -1 && id > root->right->data[0]) return avlLeftRotate(root);
    if (bf > 1 && id > root->left->data[0]) {
        root->left = avlLeftRotate(root->left);
        return avlRightRotate(root);
    }
    if (bf < -1 && id < root->right->data[0]) {
        root->right = avlRightRotate(root->right);
        return avlLeftRotate(root);
    }
    return root;
}

PairNode* avlMinNode(PairNode* n) {
    while (n->left) n = n->left;
    return n;
}

PairNode* avlDelete(PairNode* root, string id) {
    if (!root) return nullptr;
    if (id < root->data[0]) root->left = avlDelete(root->left, id);
    else if (id > root->data[0]) root->right = avlDelete(root->right, id);
    else {
        if (!root->left || !root->right) {
            PairNode* temp = root->left ? root->left : root->right;
            delete root; return temp;
        }
        PairNode* suc = avlMinNode(root->right);
        root->data[0] = suc->data[0];
        root->data[1] = suc->data[1];
        root->right = avlDelete(root->right, suc->data[0]);
    }
    int bf = avlBalance(root);
    if (bf > 1 && avlBalance(root->left) >= 0) return avlRightRotate(root);
    if (bf > 1 && avlBalance(root->left) < 0) {
        root->left = avlLeftRotate(root->left);
        return avlRightRotate(root);
    }
    if (bf < -1 && avlBalance(root->right) <= 0) return avlLeftRotate(root);
    if (bf < -1 && avlBalance(root->right) > 0) {
        root->right = avlRightRotate(root->right);
        return avlLeftRotate(root);
    }
    return root;
}

string avlSearch(PairNode* root, string id) {
    if (!root) return "";
    if (id == root->data[0]) return root->data[1];
    if (id < root->data[0]) return avlSearch(root->left, id);
    return avlSearch(root->right, id);
}

void avlInorder(PairNode* root) {
    if (!root) return;
    avlInorder(root->left);
    cout << "| " << root->data[0] << "\t\t| " << root->data[1] << "\t\t|" << endl;
    avlInorder(root->right);
}

// ========== Main with Menu ==========
int main() {
    MaxHeap<string> ID;
    PairNode* password = nullptr;
    int choice;

    do {
        cout << "\n===== User ID-Password System =====\n";
        cout << "1. Add User\n2. Remove User\n3. Search Password\n4. Display All\n0. Exit\n";
        cout << "Choice: "; cin >> choice;

        if (choice == 1) {
            string id, pw;
            cout << "Enter User ID: "; cin >> id;
            cout << "Enter Password: "; cin >> pw;
            ID.insert(id);
            password = avlInsert(password, id, pw);
            cout << "User added successfully.\n";

        } else if (choice == 2) {
            string id;
            cout << "Enter User ID to remove: "; cin >> id;
            if (!ID.search(id)) { cout << "User not found.\n"; continue; }
            ID.remove(id);
            password = avlDelete(password, id);
            cout << "User removed.\n";

        } else if (choice == 3) {
            string id;
            cout << "Enter User ID to search: "; cin >> id;
            string pw = avlSearch(password, id);
            if (pw.empty()) cout << "User not found.\n";
            else cout << "Password for " << id << ": " << pw << endl;

        } else if (choice == 4) {
            cout << "\n+----------------+----------------+\n";
            cout << "| User ID\t\t| Password\t\t|\n";
            cout << "+----------------+----------------+\n";
            avlInorder(password);
            cout << "+----------------+----------------+\n";
            cout << "IDs in MaxHeap: "; ID.display();
        }

    } while (choice != 0);

    cout << "Exiting.\n";
    return 0;
}
