/*
 * Task 1: AVL Tree Implementation
 *
 * UNDERSTANDING:
 * An AVL Tree is a self-balancing Binary Search Tree where the height difference
 * (balance factor) between left and right subtrees of any node is at most 1.
 * After every insertion or deletion, we check the balance factor and perform
 * rotations to restore balance if needed.
 *
 * SOLUTION STEPS:
 * 1. height(root): Recursively compute max depth of left/right subtree + 1
 * 2. balance(root): height(left) - height(right) gives balance factor
 * 3. balanceType(parent, newValue): After insertion, determine imbalance:
 *    - LL: new value < parent->left->data
 *    - RR: new value > parent->right->data
 *    - LR: new value > parent->left->data (but inserted in left subtree)
 *    - RL: new value < parent->right->data (but inserted in right subtree)
 * 4. leftRotate(root): Pivot right child up; root goes to left of new root
 * 5. rightRotate(root): Pivot left child up; root goes to right of new root
 * 6. bstInsert: Standard BST insert, returns inserted node
 * 7. insert: BST insert + rebalance using rotations
 * 8. bstDelete: Standard BST delete returning replacement node
 * 9. delete: BST delete + rebalance
 *
 * FUNCTIONS REUSED:
 * - insert() reuses: height(), balance(), balanceType(), leftRotate(), rightRotate(), bstInsert()
 * - deleteNode() reuses: height(), balance(), balanceType(), leftRotate(), rightRotate(), bstDelete()
 *
 * PROGRESSION EXAMPLE (insertions: 30, 20, 10):
 *   Insert 30: (30)
 *   Insert 20: (30 -> 20)
 *   Insert 10: (30 -> 20 -> 10) => LL imbalance at 30 => rightRotate => (20 -> 10, 30)
 *
 * LEARNING:
 * AVL trees guarantee O(log n) search/insert/delete by keeping the tree balanced.
 * Rotations are the key mechanism — they restructure without violating BST ordering.
 *
 * SKILLS DEVELOPED:
 * Recursive tree manipulation, identifying imbalance types, implementing rotations.
 * Can now solve problems involving balanced BSTs, sorted data with fast lookup/insert.
 */

#include <iostream>
using namespace std;

template <class T>
struct Node {
    T data;
    Node* left;
    Node* right;
    Node(T val) : data(val), left(nullptr), right(nullptr) {}
};

template <class T>
int height(Node<T>* root) {
    if (root == nullptr) return 0;
    int leftH = height(root->left);
    int rightH = height(root->right);
    return 1 + (leftH > rightH ? leftH : rightH);
}

template <class T>
int balance(Node<T>* root) {
    if (root == nullptr) return 0;
    return height(root->left) - height(root->right);
}

template <class T>
int balanceType(Node<T>* parent, T newValue) {
    // Returns: 0=balanced, 1=LL, 2=RR, 3=LR, 4=RL
    if (parent == nullptr) return 0;
    int bf = balance(parent);
    if (bf >= -1 && bf <= 1) return 0;
    if (bf > 1) {
        if (newValue < parent->left->data) return 1; // LL
        return 3;                                      // LR
    }
    if (newValue > parent->right->data) return 2;     // RR
    return 4;                                          // RL
}

template <class T>
Node<T>* leftRotate(Node<T>* root) {
    Node<T>* newRoot = root->right;
    root->right = newRoot->left;
    newRoot->left = root;
    return newRoot;
}

template <class T>
Node<T>* rightRotate(Node<T>* root) {
    Node<T>* newRoot = root->left;
    root->left = newRoot->right;
    newRoot->right = root;
    return newRoot;
}

template <class T>
Node<T>* bstInsert(Node<T>* root, T value) {
    if (root == nullptr) return new Node<T>(value);
    if (value < root->data)
        root->left = bstInsert(root->left, value);
    else if (value > root->data)
        root->right = bstInsert(root->right, value);
    return root;
}

template <class T>
Node<T>* insert(Node<T>* root, T value) {
    root = bstInsert(root, value);
    int bf = balance(root);
    if (bf > 1 && value < root->left->data)
        return rightRotate(root);                            // LL
    if (bf < -1 && value > root->right->data)
        return leftRotate(root);                             // RR
    if (bf > 1 && value > root->left->data) {               // LR
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (bf < -1 && value < root->right->data) {             // RL
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

template <class T>
Node<T>* minNode(Node<T>* root) {
    while (root->left != nullptr) root = root->left;
    return root;
}

template <class T>
Node<T>* bstDelete(Node<T>* root, T value) {
    if (root == nullptr) return nullptr;
    if (value < root->data)
        root->left = bstDelete(root->left, value);
    else if (value > root->data)
        root->right = bstDelete(root->right, value);
    else {
        if (root->left == nullptr || root->right == nullptr) {
            Node<T>* temp = root->left ? root->left : root->right;
            delete root;
            return temp;
        }
        Node<T>* successor = minNode(root->right);
        root->data = successor->data;
        root->right = bstDelete(root->right, successor->data);
    }
    return root;
}

template <class T>
Node<T>* deleteNode(Node<T>* root, T value) {
    root = bstDelete(root, value);
    if (root == nullptr) return nullptr;
    int bf = balance(root);
    if (bf > 1 && balance(root->left) >= 0)
        return rightRotate(root);
    if (bf > 1 && balance(root->left) < 0) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }
    if (bf < -1 && balance(root->right) <= 0)
        return leftRotate(root);
    if (bf < -1 && balance(root->right) > 0) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }
    return root;
}

template <class T>
void inorder(Node<T>* root) {
    if (root == nullptr) return;
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

int main() {
    Node<int>* root = nullptr;
    int values[] = {30, 20, 10, 25, 40, 50};
    cout << "Inserting: 30 20 10 25 40 50" << endl;
    for (int v : values)
        root = insert(root, v);
    cout << "Inorder after insertions: ";
    inorder(root);
    cout << endl;
    cout << "Height: " << height(root) << ", Balance: " << balance(root) << endl;
    root = deleteNode(root, 20);
    cout << "Inorder after deleting 20: ";
    inorder(root);
    cout << endl;
    return 0;
}
