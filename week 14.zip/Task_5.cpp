/*
 * Task 5: Hashtable with BST Chaining
 *
 * UNDERSTANDING:
 * This task combines a hashtable (array) with BST chaining for collision resolution.
 * Each array slot holds a pointer to a BST root. When multiple strings hash to the
 * same index, they are stored as nodes in the BST at that index.
 * This gives O(1) average + O(log k) worst-case per bucket (k = bucket size).
 *
 * SOLUTION STEPS:
 * 1. Reuse getHashCode() from Task 4 to determine array index for a string
 * 2. add(): hash string -> get index -> BST insert at that index
 * 3. search(): hash string -> get index -> BST search at that index
 * 4. remove(): hash string -> get index -> BST delete at that index
 *
 * FUNCTIONS REUSED:
 * - getHashCode() from Task 4 (reused for index calculation)
 * - BST insert, search, delete (standard BST operations on string nodes)
 * - All three hashtable functions reuse getHashCode()
 *
 * PROGRESSION EXAMPLE (size=5, strings "cat","car","cab"):
 *   hash("cat") -> idx=0 -> BST[0]: (cat)
 *   hash("car") -> idx=0 -> BST[0]: (cat) with (car) as child
 *   hash("cab") -> idx=0 -> BST[0]: (cat) with (car, cab) as children
 *   search("car") -> idx=0 -> traverse BST[0] -> found
 *   remove("cat") -> idx=0 -> BST delete, successor replaces
 *
 * LEARNING:
 * BST chaining is more efficient than linked-list chaining for large buckets
 * because search is O(log k) instead of O(k). This hybrid approach is used
 * in real implementations like Java's HashMap (uses trees for large buckets).
 *
 * SKILLS DEVELOPED:
 * Combining hashtables with tree-based collision resolution.
 * Can now implement efficient symbol tables, compilers, and database indices.
 */

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

// ========== BST Node ==========
struct Node {
    string data;
    Node* left;
    Node* right;
    Node(string val) : data(val), left(nullptr), right(nullptr) {}
};

// ========== getHashCode (reused from Task 4) ==========
int getHashCode(char* str) {
    int sum = 0;
    int len = strlen(str);
    if (len == 0) return 0;
    for (int i = 0; i < len; i++) sum += (int)str[i];
    return sum % len;
}

// ========== BST Helper Functions ==========
Node* bstInsertStr(Node* root, string val) {
    if (!root) return new Node(val);
    if (val < root->data) root->left = bstInsertStr(root->left, val);
    else if (val > root->data) root->right = bstInsertStr(root->right, val);
    return root;
}

bool bstSearchStr(Node* root, string val) {
    if (!root) return false;
    if (val == root->data) return true;
    if (val < root->data) return bstSearchStr(root->left, val);
    return bstSearchStr(root->right, val);
}

Node* bstMinNode(Node* n) {
    while (n->left) n = n->left;
    return n;
}

Node* bstDeleteStr(Node* root, string val) {
    if (!root) return nullptr;
    if (val < root->data) root->left = bstDeleteStr(root->left, val);
    else if (val > root->data) root->right = bstDeleteStr(root->right, val);
    else {
        if (!root->left || !root->right) {
            Node* temp = root->left ? root->left : root->right;
            delete root;
            return temp;
        }
        Node* suc = bstMinNode(root->right);
        root->data = suc->data;
        root->right = bstDeleteStr(root->right, suc->data);
    }
    return root;
}

// ========== Hashtable Functions ==========

// Add string to hashtable array using BST at hashed index
void add(Node** a, int size, string str) {
    char* cstr = new char[str.length() + 1];
    strcpy(cstr, str.c_str());
    int idx = getHashCode(cstr) % size;
    a[idx] = bstInsertStr(a[idx], str);
    delete[] cstr;
}

// Search string in hashtable using BST at hashed index
bool search(Node** a, int size, string str) {
    char* cstr = new char[str.length() + 1];
    strcpy(cstr, str.c_str());
    int idx = getHashCode(cstr) % size;
    delete[] cstr;
    return bstSearchStr(a[idx], str);
}

// Remove string from hashtable using BST at hashed index; returns removed string
string removeStr(Node** a, int size, string str) {
    char* cstr = new char[str.length() + 1];
    strcpy(cstr, str.c_str());
    int idx = getHashCode(cstr) % size;
    delete[] cstr;
    if (!bstSearchStr(a[idx], str)) return "";
    a[idx] = bstDeleteStr(a[idx], str);
    return str;
}

// Display BST inorder at each index
void inorderBST(Node* root) {
    if (!root) return;
    inorderBST(root->left);
    cout << root->data << " ";
    inorderBST(root->right);
}

void displayTable(Node** a, int size) {
    cout << "\n=== Hashtable Contents ===" << endl;
    for (int i = 0; i < size; i++) {
        cout << "[" << i << "]: ";
        if (a[i]) inorderBST(a[i]);
        else cout << "(empty)";
        cout << endl;
    }
}

int main() {
    const int SIZE = 5;
    Node* table[SIZE] = {nullptr};

    string words[] = {"apple", "avocado", "banana", "cherry", "apricot", "blueberry"};
    cout << "=== Adding strings to hashtable ===" << endl;
    for (string w : words) {
        add(table, SIZE, w);
        cout << "Added: " << w << endl;
    }

    displayTable(table, SIZE);

    // Search
    cout << "\n=== Search Tests ===" << endl;
    cout << "search(\"banana\"): " << (search(table, SIZE, "banana") ? "Found" : "Not Found") << endl;
    cout << "search(\"grape\"): "  << (search(table, SIZE, "grape")  ? "Found" : "Not Found") << endl;

    // Remove
    cout << "\n=== Remove Tests ===" << endl;
    string removed = removeStr(table, SIZE, "apple");
    if (removed.empty()) cout << "apple not found.\n";
    else cout << "Removed: " << removed << endl;

    removed = removeStr(table, SIZE, "mango");
    if (removed.empty()) cout << "mango not found.\n";
    else cout << "Removed: " << removed << endl;

    displayTable(table, SIZE);
    return 0;
}
