/*
 * Task 4: Hashtable Function Implementations
 *
 * UNDERSTANDING:
 * A hashtable maps keys to indices in an array for O(1) average access.
 * Collisions (two values mapping to same index) are resolved using:
 * - Linear Probing: try index+1, index+2, ...
 * - Quadratic Probing: try index+offset^2
 * - Double Hashing: second hash function determines step size
 * For strings, a hash function sums ASCII values mod string length.
 *
 * SOLUTION STEPS:
 * 1. getIndex(value, size): Basic modulo hash — value % size
 * 2. getLinearKey: (value + offset) % size — linear probing step
 * 3. getQuardKey: (getIndex(v,s) + offset^2) % size — quadratic probing
 * 4. getCode: double hashing — (getIndex + offset * getQuardKey) % size
 * 5. getHashCode(str): sum of ASCII of each char % length of str
 * 6. insert(int array): use getQuardKey to find slot and store value
 * 7. retrieve(int array): use getQuardKey to find slot and return value
 * 8. insert(string array): use getHashCode to find slot and store string
 * 9. retrieve(string array): use getHashCode to find slot and return string
 *
 * FUNCTIONS REUSED:
 * - getLinearKey reuses getIndex
 * - getQuardKey reuses getIndex
 * - getCode reuses getIndex and getQuardKey
 * - insert/retrieve for int reuses getQuardKey
 * - insert/retrieve for string reuses getHashCode
 *
 * PROGRESSION EXAMPLE (size=7, inserting 10, 17, 24):
 *   getIndex(10, 7) = 3
 *   getIndex(17, 7) = 3 => collision => getQuardKey(17,7,1) = (3+1)%7 = 4
 *   getIndex(24, 7) = 3 => getQuardKey(24,7,1)=4, getQuardKey(24,7,2)=(3+4)%7=0
 *
 * LEARNING:
 * Hashing enables near-constant time data access. Collision resolution strategy
 * greatly affects performance under load. Quadratic probing avoids clustering better than linear.
 *
 * SKILLS DEVELOPED:
 * Implementing hash functions and probing strategies.
 * Can now build dictionaries, caches, frequency counters, and lookup tables.
 */

#include <iostream>
#include <string>
#include <cstring>
using namespace std;

// Basic modulo hash
int getIndex(int value, int size) {
    return value % size;
}

// Linear probing key
int getLinearKey(int value, int size, int offset) {
    return (getIndex(value, size) + offset) % size;
}

// Quadratic probing key
int getQuardKey(int value, int size, int offset) {
    return (getIndex(value, size) + offset * offset) % size;
}

// Double hashing key
int getCode(int value, int size, int offset) {
    return (getIndex(value, size) + offset * getQuardKey(value, size, offset)) % size;
}

// String hash: sum of ASCII values % length of string
int getHashCode(char* str) {
    int sum = 0;
    int len = strlen(str);
    for (int i = 0; i < len; i++) sum += (int)str[i];
    return sum % len;
}

// Insert integer using quadratic probing
void insert(int* a, int size, int offset, int value) {
    int idx = getQuardKey(value, size, offset);
    a[idx] = value;
}

// Retrieve integer using quadratic probing
int retrieve(int* a, int size, int offset) {
    return a[getQuardKey(0, size, offset)]; // offset-based retrieval
}

// Insert string using getHashCode
void insert(string* a, int size, int offset, string str) {
    char* cstr = new char[str.length() + 1];
    strcpy(cstr, str.c_str());
    int idx = (getHashCode(cstr) + offset) % size;
    a[idx] = str;
    delete[] cstr;
}

// Retrieve string using getHashCode
string retrieve(string* a, int size, int offset) {
    return a[offset % size];
}

int main() {
    const int SIZE = 7;

    // Integer hashtable
    int intTable[SIZE] = {0};
    int testVals[] = {10, 17, 24, 3};
    cout << "=== Integer Hashtable (Quadratic Probing) ===" << endl;
    for (int v : testVals) {
        insert(intTable, SIZE, 0, v);
        cout << "Inserted " << v << " at index " << getQuardKey(v, SIZE, 0) << endl;
    }
    cout << "Table: ";
    for (int i = 0; i < SIZE; i++) cout << "[" << i << "]=" << intTable[i] << " ";
    cout << endl;

    // String hashtable
    string strTable[SIZE];
    string words[] = {"hello", "world", "hash", "test"};
    cout << "\n=== String Hashtable (getHashCode) ===" << endl;
    for (string w : words) {
        char* cw = new char[w.length() + 1];
        strcpy(cw, w.c_str());
        int idx = getHashCode(cw);
        cout << "'" << w << "' -> hashCode=" << idx << endl;
        insert(strTable, SIZE, 0, w);
        delete[] cw;
    }

    // Test getCode and getLinearKey
    cout << "\n=== Key Function Tests ===" << endl;
    cout << "getIndex(25, 7) = " << getIndex(25, 7) << endl;
    cout << "getLinearKey(25, 7, 2) = " << getLinearKey(25, 7, 2) << endl;
    cout << "getQuardKey(25, 7, 2) = " << getQuardKey(25, 7, 2) << endl;
    cout << "getCode(25, 7, 2) = " << getCode(25, 7, 2) << endl;

    char testStr[] = "hello";
    cout << "getHashCode(\"hello\") = " << getHashCode(testStr) << endl;

    return 0;
}
