#include <iostream>
using namespace std;

template <class T>
class Node
{
public:
	T data;
	Node* next;
	Node* prev;

	Node(T d)
	{
		data = d;
		next = nullptr;
		prev = nullptr;
	}
};

template <class T>
class ConcreteDoublyLinkedList
{
private:
	Node<T>* head;
	Node<T>* tail;

public:
	ConcreteDoublyLinkedList()
	{
		head = nullptr;
		tail = nullptr;
	}

	bool isEmpty()
	{
		return head == nullptr;
	}

	void insertAtFirst(T value)
	{
		Node<T>* newNode = new Node<T>(value);

		if (isEmpty())
		{
			head = tail = newNode;
		}
		else
		{
			newNode->next = head;
			head->prev = newNode;
			head = newNode;
		}
	}

	void insertAtLast(T value)
	{
		Node<T>* newNode = new Node<T>(value);

		if (isEmpty())
		{
			head = tail = newNode;
		}
		else
		{
			tail->next = newNode;
			newNode->prev = tail;
			tail = newNode;
		}
	}

	bool removeFromFirst(T &value)
	{
		if (isEmpty())
			return false;

		Node<T>* temp = head;

		value = head->data;

		head = head->next;

		if (head != nullptr)
			head->prev = nullptr;
		else
			tail = nullptr;

		delete temp;

		return true;
	}

	bool removeFromLast(T &value)
	{
		if (isEmpty())
			return false;

		Node<T>* temp = tail;

		value = tail->data;

		tail = tail->prev;

		if (tail != nullptr)
			tail->next = nullptr;
		else
			head = nullptr;

		delete temp;

		return true;
	}
};

/*
=====================================================
Recursive Copy Linked List

Base Case:
List becomes empty

Recursive Case:
Remove last value
Insert at first in copy
Call again
=====================================================
*/

void LLCopyRecursive(ConcreteDoublyLinkedList<int> src,
	ConcreteDoublyLinkedList<int> &copy)
{
	if (src.isEmpty())
		return;

	int x = 0;

	src.removeFromLast(x);

	copy.insertAtFirst(x);

	LLCopyRecursive(src, copy);
}

/*
=====================================================
Recursive Display Function

Base Case:
List empty

Recursive Case:
Remove first value
Print it
Call recursively
=====================================================
*/

void displayRecursive(ConcreteDoublyLinkedList<int> as)
{
	if (as.isEmpty())
	{
		cout << "NULL" << endl;
		return;
	}

	int v = 0;

	as.removeFromFirst(v);

	cout << v << " -> ";

	displayRecursive(as);
}

/*
=====================================================
Recursive Size Function

Base Case:
List empty ? size 0

Recursive Case:
1 + remaining size
=====================================================
*/

int getSizeRecursive(ConcreteDoublyLinkedList<int> as)
{
	if (as.isEmpty())
		return 0;

	int v = 0;

	as.removeFromLast(v);

	return 1 + getSizeRecursive(as);
}

/*
=====================================================
Recursive Maximum Function

Base Case:
One element left

Recursive Case:
Compare current value
with maximum of remaining list
=====================================================
*/

int maxRecursive(ConcreteDoublyLinkedList<int> as)
{
	int v = 0;

	as.removeFromLast(v);

	if (as.isEmpty())
		return v;

	int mx = maxRecursive(as);

	if (v > mx)
		return v;

	return mx;
}

/*
=====================================================
Count Frequency of One Value

Base Case:
List empty

Recursive Case:
If value matches ? count +1
=====================================================
*/

int countFrequency(ConcreteDoublyLinkedList<int> as,
	int value)
{
	if (as.isEmpty())
		return 0;

	int v = 0;

	as.removeFromFirst(v);

	if (v == value)
		return 1 + countFrequency(as, value);

	return countFrequency(as, value);
}

/*
=====================================================
Check if Value Already Processed
=====================================================
*/

bool contains(ConcreteDoublyLinkedList<int> as,
	int value)
{
	if (as.isEmpty())
		return false;

	int v = 0;

	as.removeFromFirst(v);

	if (v == value)
		return true;

	return contains(as, value);
}

/*
=====================================================
Helper Function for Frequency List

Stores:
value -> frequency
=====================================================
*/

void frequencyHelper(ConcreteDoublyLinkedList<int> adt,
	ConcreteDoublyLinkedList<int> &freqList,
	ConcreteDoublyLinkedList<int> &checked)
{
	if (adt.isEmpty())
		return;

	int v = 0;

	adt.removeFromFirst(v);

	if (!contains(checked, v))
	{
		int freq = countFrequency(adt, v) + 1;

		checked.insertAtLast(v);

		freqList.insertAtLast(v);
		freqList.insertAtLast(freq);
	}

	frequencyHelper(adt, freqList, checked);
}

/*
=====================================================
Main Frequency Function
=====================================================
*/

ConcreteDoublyLinkedList<int> frequency(
	ConcreteDoublyLinkedList<int> adt)
{
	ConcreteDoublyLinkedList<int> freqList;
	ConcreteDoublyLinkedList<int> checked;

	frequencyHelper(adt, freqList, checked);

	return freqList;
}

/*
=====================================================
MAIN FUNCTION
=====================================================
*/

int main()
{
	ConcreteDoublyLinkedList<int> list;

	list.insertAtLast(5);
	list.insertAtLast(3);
	list.insertAtLast(5);
	list.insertAtLast(2);
	list.insertAtLast(3);
	list.insertAtLast(5);

	cout << "Original List: ";
	displayRecursive(list);

	cout << endl;

	cout << "List Size = ";
	cout << getSizeRecursive(list) << endl;

	cout << endl;

	cout << "Maximum Value = ";
	cout << maxRecursive(list) << endl;

	cout << endl;

	ConcreteDoublyLinkedList<int> copied;

	LLCopyRecursive(list, copied);

	cout << "Copied List: ";
	displayRecursive(copied);

	cout << endl;

	ConcreteDoublyLinkedList<int> freq =
		frequency(list);

	cout << "Frequency List: ";
	displayRecursive(freq);

	return 0;
}