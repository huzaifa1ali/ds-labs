#include <iostream>
using namespace std;

class Node
{
public:
	int data;
	Node* next;
	Node* prev;

	Node(int d)
	{
		data = d;
		next = nullptr;
		prev = nullptr;
	}
};

class DoublyLinkedList
{
public:
	virtual void insertAtEnd(int value) = 0;
	virtual void insertAtStart(int value) = 0;
	virtual void displayForward() = 0;
	virtual void displayBackward() = 0;
	virtual int countNodes() = 0;
};

class ConcreteDoublyLinkedList : public DoublyLinkedList
{
private:
	Node* head;
	Node* tail;

	void displayForwardRecursive(Node* node)
	{
		if (node == nullptr)
			return;

		cout << node->data << " ";
		displayForwardRecursive(node->next);
	}

	void displayBackwardRecursive(Node* node)
	{
		if (node == nullptr)
			return;

		cout << node->data << " ";
		displayBackwardRecursive(node->prev);
	}

	int countRecursive(Node* node)
	{
		if (node == nullptr)
			return 0;

		return 1 + countRecursive(node->next);
	}

public:
	ConcreteDoublyLinkedList()
	{
		head = nullptr;
		tail = nullptr;
	}

	void insertAtStart(int value)
	{
		Node* newNode = new Node(value);

		if (head == nullptr)
		{
			head = tail = newNode;
		}
		else
		{
			newNode->next = head;
			head->prev = newNode;
			head = newNode;
		}
	}

	void insertAtEnd(int value)
	{
		Node* newNode = new Node(value);

		if (tail == nullptr)
		{
			head = tail = newNode;
		}
		else
		{
			tail->next = newNode;
			newNode->prev = tail;
			tail = newNode;
		}
	}

	void displayForward()
	{
		cout << "Forward List: ";
		displayForwardRecursive(head);
		cout << endl;
	}

	void displayBackward()
	{
		cout << "Backward List: ";
		displayBackwardRecursive(tail);
		cout << endl;
	}

	int countNodes()
	{
		return countRecursive(head);
	}
};

int main()
{
	ConcreteDoublyLinkedList list;

	list.insertAtEnd(10);
	list.insertAtEnd(20);
	list.insertAtEnd(30);

	list.insertAtStart(5);
	list.insertAtStart(1);

	list.displayForward();

	list.displayBackward();

	cout << "Total Nodes: " << list.countNodes() << endl;

	return 0;
}