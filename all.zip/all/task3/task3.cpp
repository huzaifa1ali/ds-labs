#include <iostream>
using namespace std;

template <class T>
class ArrayStack
{
private:
	T arr[100];
	int top;

public:
	ArrayStack()
	{
		top = -1;
	}

	bool isEmpty()
	{
		return top == -1;
	}

	bool push(T value)
	{
		if (top == 99)
			return false;

		arr[++top] = value;
		return true;
	}

	bool pop(T &value)
	{
		if (isEmpty())
			return false;

		value = arr[top--];
		return true;
	}
};

void copyStackRecursive(ArrayStack<int> &src, ArrayStack<int> &copy)
{
	if (src.isEmpty())
		return;

	int v;

	src.pop(v);

	copy.push(v);

	copyStackRecursive(src, copy);
}

void displayRecursive(ArrayStack<int> as)
{
	if (as.isEmpty())
	{
		cout << endl;
		return;
	}

	int v;

	as.pop(v);

	cout << v << " ";

	displayRecursive(as);
}

int getSizeRecursive(ArrayStack<int> as)
{
	if (as.isEmpty())
		return 0;

	int v;

	as.pop(v);

	return 1 + getSizeRecursive(as);
}

int maxRecursive(ArrayStack<int> as)
{
	int v;

	as.pop(v);

	if (as.isEmpty())
		return v;

	int mx = maxRecursive(as);

	if (v > mx)
		return v;

	return mx;
}

int countFrequency(ArrayStack<int> as, int value)
{
	if (as.isEmpty())
		return 0;

	int v;

	as.pop(v);

	if (v == value)
		return 1 + countFrequency(as, value);

	return countFrequency(as, value);
}

bool contains(ArrayStack<int> as, int value)
{
	if (as.isEmpty())
		return false;

	int v;

	as.pop(v);

	if (v == value)
		return true;

	return contains(as, value);
}

void frequencyHelper(ArrayStack<int> adt,
	ArrayStack<int> &freqStack,
	ArrayStack<int> &checked)
{
	if (adt.isEmpty())
		return;

	int v;

	adt.pop(v);

	if (!contains(checked, v))
	{
		int freq = countFrequency(adt, v) + 1;

		checked.push(v);

		freqStack.push(v);
		freqStack.push(freq);
	}

	frequencyHelper(adt, freqStack, checked);
}

ArrayStack<int> frequency(ArrayStack<int> adt)
{
	ArrayStack<int> freqStack;
	ArrayStack<int> checked;

	frequencyHelper(adt, freqStack, checked);

	return freqStack;
}

int main()
{
	ArrayStack<int> s;

	s.push(5);
	s.push(3);
	s.push(5);
	s.push(2);
	s.push(3);
	s.push(5);

	cout << "Original Stack: ";
	displayRecursive(s);

	cout << endl;

	cout << "Stack Size = ";
	cout << getSizeRecursive(s) << endl;

	cout << endl;

	cout << "Maximum Value = ";
	cout << maxRecursive(s) << endl;

	cout << endl;

	ArrayStack<int> copied;

	copyStackRecursive(s, copied);

	cout << "Copied Stack: ";
	displayRecursive(copied);

	cout << endl;

	ArrayStack<int> freq = frequency(s);

	cout << "Frequency Stack (Value Frequency): ";
	displayRecursive(freq);

	return 0;
}