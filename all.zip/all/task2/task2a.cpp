#include <iostream>
using namespace std;

void funcRecursive(int n)
{
	if (n <= 0)
		return;

	cout << n << endl;
	funcRecursive(n - 1);
}

int sumRecursive(int n)
{
	if (n <= 0)
		return 0;

	return n + sumRecursive(n - 1);
}

int maxRecursive(int a[], int size)
{
	if (size == 1)
		return a[0];

	int m = maxRecursive(a, size - 1);

	if (a[size - 1] > m)
		return a[size - 1];

	return m;
}

int countDigitsRecursive(int n)
{
	if (n == 0)
		return 0;

	int count = 0;

	if (n % 10 != 0)
		count = 1;

	return count + countDigitsRecursive(n / 10);
}

void displayDigitsRecursive(int n)
{
	if (n == 0)
	{
		cout << endl;
		return;
	}

	cout << n % 10 << " ";
	displayDigitsRecursive(n / 10);
}

int binarySearchRecursive(int a[], int low, int high, int v)
{
	if (low > high)
		return -1;

	int mid = (low + high) / 2;

	if (a[mid] == v)
		return mid;

	if (v > a[mid])
		return binarySearchRecursive(a, mid + 1, high, v);

	return binarySearchRecursive(a, low, mid - 1, v);
}

int main()
{
	cout << "Function Output:" << endl;
	funcRecursive(5);

	cout << endl;

	cout << "Sum = " << sumRecursive(10) << endl;

	cout << endl;

	int arr[] = { 4, 9, 2, 15, 7, 20 };

	cout << "Maximum = " << maxRecursive(arr, 6) << endl;

	cout << endl;

	cout << "Non-zero Digits Count = ";
	cout << countDigitsRecursive(1020304) << endl;

	cout << endl;

	cout << "Digits Display: ";
	displayDigitsRecursive(12345);

	cout << endl;

	int sortedArr[] = { 2, 4, 6, 8, 10, 12, 14 };

	int index = binarySearchRecursive(sortedArr, 0, 6, 10);

	cout << "Binary Search Index = " << index << endl;

	return 0;
}