#include <iostream>
using namespace std;

template <class T>
class ArrayQueue
{
private:
	T arr[100];
	int front;
	int rear;

public:
	ArrayQueue()
	{
		front = 0;
		rear = -1;
	}

	bool isEmpty()
	{
		return rear < front;
	}

	void enqueue(T value)
	{
		arr[++rear] = value;
	}

	T dequeue()
	{
		return arr[front++];
	}
};

/*
=====================================================
Recursive Copy Queue

Base Case:
Queue becomes empty

Recursive Case:
Dequeue one value
Enqueue into copy
Call function again
=====================================================
*/

void copyQueueRecursive(ArrayQueue<int> src,
	ArrayQueue<int> &copy)
{
	if (src.isEmpty())
		return;

	int v = src.dequeue();

	copy.enqueue(v);

	copyQueueRecursive(src, copy);
}

/*
=====================================================
Recursive Display Queue

Base Case:
Queue becomes empty

Recursive Case:
Print front value
Call recursively
=====================================================
*/

void displayRecursive(ArrayQueue<int> q)
{
	if (q.isEmpty())
	{
		cout << endl;
		return;
	}

	int v = q.dequeue();

	cout << v << " ";

	displayRecursive(q);
}

/*
=====================================================
Recursive Size Function

Base Case:
Queue empty ? size 0

Recursive Case:
1 + remaining size
=====================================================
*/

int getSizeRecursive(ArrayQueue<int> q)
{
	if (q.isEmpty())
		return 0;

	q.dequeue();

	return 1 + getSizeRecursive(q);
}

/*
=====================================================
Recursive Maximum Function

Base Case:
Only one element left

Recursive Case:
Compare current value with
maximum of remaining queue
=====================================================
*/

int maxRecursive(ArrayQueue<int> q)
{
	int v = q.dequeue();

	if (q.isEmpty())
		return v;

	int mx = maxRecursive(q);

	if (v > mx)
		return v;

	return mx;
}

/*
=====================================================
Count Frequency of One Value

Base Case:
Queue empty

Recursive Case:
If value matches ? count +1
=====================================================
*/

int countFrequency(ArrayQueue<int> q, int value)
{
	if (q.isEmpty())
		return 0;

	int v = q.dequeue();

	if (v == value)
		return 1 + countFrequency(q, value);

	return countFrequency(q, value);
}

/*
=====================================================
Check if Value Already Processed

Base Case:
Queue empty ? false

Recursive Case:
Check current value
=====================================================
*/

bool contains(ArrayQueue<int> q, int value)
{
	if (q.isEmpty())
		return false;

	int v = q.dequeue();

	if (v == value)
		return true;

	return contains(q, value);
}

/*
=====================================================
Helper Function for Frequency Queue

Stores:
value then frequency

Example:
5 3 means value 5 occurs 3 times
=====================================================
*/

void frequencyHelper(ArrayQueue<int> adt,
	ArrayQueue<int> &freqQueue,
	ArrayQueue<int> &checked)
{
	if (adt.isEmpty())
		return;

	int v = adt.dequeue();

	if (!contains(checked, v))
	{
		int freq = countFrequency(adt, v) + 1;

		checked.enqueue(v);

		freqQueue.enqueue(v);
		freqQueue.enqueue(freq);
	}

	frequencyHelper(adt, freqQueue, checked);
}

/*
=====================================================
Main Frequency Function
=====================================================
*/

ArrayQueue<int> frequency(ArrayQueue<int> adt)
{
	ArrayQueue<int> freqQueue;
	ArrayQueue<int> checked;

	frequencyHelper(adt, freqQueue, checked);

	return freqQueue;
}

/*
=====================================================
MAIN FUNCTION
=====================================================
*/

int main()
{
	ArrayQueue<int> q;

	q.enqueue(5);
	q.enqueue(3);
	q.enqueue(5);
	q.enqueue(2);
	q.enqueue(3);
	q.enqueue(5);

	cout << "Original Queue: ";
	displayRecursive(q);

	cout << endl;

	cout << "Queue Size = ";
	cout << getSizeRecursive(q) << endl;

	cout << endl;

	cout << "Maximum Value = ";
	cout << maxRecursive(q) << endl;

	cout << endl;

	ArrayQueue<int> copied;

	copyQueueRecursive(q, copied);

	cout << "Copied Queue: ";
	displayRecursive(copied);

	cout << endl;

	ArrayQueue<int> freq = frequency(q);

	cout << "Frequency Queue (Value Frequency): ";
	displayRecursive(freq);

	return 0;
}